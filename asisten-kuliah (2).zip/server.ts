import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import nodemailer from "nodemailer";
import cors from "cors";
import { GoogleGenAI } from "@google/genai";
import webpush from "web-push";
import fs from "fs";

// Initialize express
async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));
  app.use(cors());

  // Setup VAPID keys persistently
  let vapidKeys: { publicKey: string; privateKey: string };
  const KEYS_PATH = path.join(process.cwd(), "vapid-keys.json");

  if (fs.existsSync(KEYS_PATH)) {
    try {
      vapidKeys = JSON.parse(fs.readFileSync(KEYS_PATH, "utf8"));
    } catch (e) {
      console.error("Gagal membaca file vapid-keys.json, membuat baru:", e);
      vapidKeys = webpush.generateVAPIDKeys();
      fs.writeFileSync(KEYS_PATH, JSON.stringify(vapidKeys), "utf8");
    }
  } else {
    vapidKeys = webpush.generateVAPIDKeys();
    fs.writeFileSync(KEYS_PATH, JSON.stringify(vapidKeys), "utf8");
  }

  webpush.setVapidDetails(
    "mailto:saifulanamahmad352@gmail.com",
    vapidKeys.publicKey,
    vapidKeys.privateKey
  );

  // Setup Subscription and Task Sync Database
  const DB_PATH = path.join(process.cwd(), "notifications-db.json");

  interface UserSyncData {
    subscription: any;
    userName: string;
    aiName: string;
    tasks: any[];
    schedule: any[];
    notificationDaysBefore: number;
    lastNotifiedTasks: string[]; // List of task IDs notified
    lastNotifiedSchedule: string[]; // List of schedule identifier e.g., "id-YYYY-MM-DD"
  }

  let userSyncStore: { [endpoint: string]: UserSyncData } = {};

  const loadSyncStore = () => {
    try {
      if (fs.existsSync(DB_PATH)) {
        userSyncStore = JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
      }
    } catch (err) {
      console.error("Gagal memuat notifications-db.json:", err);
    }
  };

  const saveSyncStore = () => {
    try {
      fs.writeFileSync(DB_PATH, JSON.stringify(userSyncStore, null, 2), "utf8");
    } catch (err) {
      console.error("Gagal menyimpan notifications-db.json:", err);
    }
  };

  loadSyncStore();

  // Helper to calculate current time in Asia/Jakarta (GMT+7)
  const getIndonesianDateTime = () => {
    const now = new Date();
    // Calculate off-set to represent Jakarta (GMT+7)
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    const jktDate = new Date(utc + (3600000 * 7));
    
    const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const currentDay = dayNames[jktDate.getDay()];
    const currentHour = jktDate.getHours();
    const currentMinute = jktDate.getMinutes();
    const currentTimeStr = `${String(currentHour).padStart(2, '0')}:${String(currentMinute).padStart(2, '0')}`;
    const currentTimeVal = currentHour * 60 + currentMinute;
    
    // Format YYYY-MM-DD
    const year = jktDate.getFullYear();
    const month = String(jktDate.getMonth() + 1).padStart(2, '0');
    const date = String(jktDate.getDate()).padStart(2, '0');
    const currentDateStr = `${year}-${month}-${date}`;
    
    return { currentDateStr, currentDay, currentTimeStr, currentTimeVal, jktDate };
  };

  // Background check for push notifications every 60 seconds
  setInterval(async () => {
    const { currentDateStr, currentDay, currentTimeStr, currentTimeVal, jktDate } = getIndonesianDateTime();
    const currentHour = jktDate.getHours();
    const currentMinute = jktDate.getMinutes();

    let hasChange = false;

    for (const endpoint of Object.keys(userSyncStore)) {
      const user = userSyncStore[endpoint];
      if (!user.subscription) continue;

      // Ensure lists exist
      user.lastNotifiedTasks = user.lastNotifiedTasks || [];
      user.lastNotifiedSchedule = user.lastNotifiedSchedule || [];

      // 1. Check Schedule (Notifies 5 minutes before start time)
      if (user.schedule && Array.isArray(user.schedule)) {
        user.schedule.forEach(item => {
          if (item.day === currentDay) {
            const [hours, minutes] = item.startTime.split(':').map(Number);
            const startTimeInMinutes = hours * 60 + minutes;
            const notificationId = `${item.id}-${currentDateStr}`;

            // Notify exactly 5 minutes before scheduled class
            if (startTimeInMinutes - currentTimeVal === 5) {
              if (!user.lastNotifiedSchedule.includes(notificationId)) {
                user.lastNotifiedSchedule.push(notificationId);
                hasChange = true;

                // Send push notification
                const payload = JSON.stringify({
                  title: `Pengingat Kegiatan: ${item.title}`,
                  body: `Kegiatan ini akan dimulai jam ${item.startTime}! Ayo bersiap-siap.`,
                  url: "/?tab=schedule"
                });

                webpush.sendNotification(user.subscription, payload).catch(err => {
                  console.error("Gagal mengirim push schedule:", err.statusCode);
                });
              }
            }
          }
        });
      }

      // 2. Check Task Deadlines (Every day at 08:00 AM)
      if (currentHour === 8 && currentMinute === 0) {
        if (user.tasks && Array.isArray(user.tasks)) {
          const daysBefore = user.notificationDaysBefore || 1;
          
          user.tasks.forEach(task => {
            if (task.isCompleted) return;

            // Calculate differences in days
            const taskTime = Date.parse(task.deadline);
            const todayTime = Date.parse(currentDateStr);
            if (isNaN(taskTime) || isNaN(todayTime)) return;

            const diffDays = Math.ceil((taskTime - todayTime) / (1000 * 60 * 60 * 24));

            if (diffDays === daysBefore) {
              if (!user.lastNotifiedTasks.includes(task.id)) {
                user.lastNotifiedTasks.push(task.id);
                hasChange = true;

                const payload = JSON.stringify({
                  title: daysBefore === 1 ? 'Deadline Tugas Besok!' : `Deadline Tugas ${daysBefore} Hari Lagi!`,
                  body: `Tugas "${task.title}" harus dikumpulkan ${daysBefore === 1 ? 'besok' : `${daysBefore} hari lagi`}. Cek progresnya sekarang!`,
                  url: "/?tab=tasks"
                });

                webpush.sendNotification(user.subscription, payload).catch(err => {
                  console.error("Gagal mengirim push task:", err.statusCode);
                });
              }
            }
          });
        }
      }
    }

    if (hasChange) {
      saveSyncStore();
    }
  }, 60000); // 1 minute interval

  // AI Setup
  const getAI = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing in server environment. Pastikan kunci API Gemini sudah dikonfigurasi di Settings > Secrets.");
    }
    return new GoogleGenAI({ 
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  };

  // Service Worker File endpoint (Dynamic & reliable integration with scope /)
  app.get("/sw.js", (req, res) => {
    res.setHeader("Content-Type", "application/javascript");
    res.send(`// Service Worker untuk Notifikasi Latar Belakang (HP / PC)
self.addEventListener('install', event => {
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', event => {
  try {
    let data = { title: 'Notifikasi Asisten Kuliah', body: 'Ada aktivitas kuliah baru!' };
    if (event.data) {
      data = event.data.json();
    }
    const options = {
      body: data.body,
      icon: '/favicon.svg',
      badge: '/favicon.svg',
      vibrate: [300, 100, 300],
      data: {
        url: data.url || '/'
      }
    };
    event.waitUntil(
      self.registration.showNotification(data.title, options)
    );
  } catch (err) {
    console.error('SW Push processing error:', err);
  }
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const urlToOpen = event.notification.data?.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windowClients => {
      for (let i = 0; i < windowClients.length; i++) {
        const client = windowClients[i];
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});`);
  });

  // VAPID Public Key exchange
  app.get("/api/notifications/vapid-key", (req, res) => {
    res.json({ publicKey: vapidKeys.publicKey });
  });

  // Subscription and task configuration sync endpoint
  app.post("/api/notifications/sync", (req, res) => {
    try {
      const { subscription, userName, aiName, tasks, schedule, notificationDaysBefore } = req.body;
      if (!subscription || !subscription.endpoint) {
        return res.status(400).json({ error: "Push subscription is required." });
      }

      // Existing entry for incremental storage preservation
      const exist: UserSyncData = userSyncStore[subscription.endpoint] || {
        subscription,
        userName: "Mahasiswa",
        aiName: "Asisten Kuliah",
        tasks: [],
        schedule: [],
        notificationDaysBefore: 1,
        lastNotifiedTasks: [],
        lastNotifiedSchedule: []
      };

      userSyncStore[subscription.endpoint] = {
        subscription,
        userName: userName || exist.userName || "Mahasiswa",
        aiName: aiName || exist.aiName || "Asisten Kuliah",
        tasks: tasks || exist.tasks || [],
        schedule: schedule || exist.schedule || [],
        notificationDaysBefore: notificationDaysBefore !== undefined ? notificationDaysBefore : exist.notificationDaysBefore,
        lastNotifiedTasks: exist.lastNotifiedTasks,
        lastNotifiedSchedule: exist.lastNotifiedSchedule
      };

      saveSyncStore();
      res.json({ success: true, message: "Sinkronisasi notifikasi berhasil!" });
    } catch (e: any) {
      console.error("Gagal menyinkronkan data notifikasi:", e);
      res.status(500).json({ error: e.message });
    }
  });

  // Test notification trigger
  app.post("/api/notifications/test-push", async (req, res) => {
    try {
      const { subscription } = req.body;
      if (!subscription) {
        return res.status(400).json({ error: "Missing subscription." });
      }

      const payload = JSON.stringify({
        title: "Test Notifikasi Berhasil! 🎉",
        body: "Hebat! Notifikasi HP & PC sekarang bisa muncul langsung meskipun aplikasi ditutup.",
        url: "/"
      });

      await webpush.sendNotification(subscription, payload);
      res.json({ success: true });
    } catch (err: any) {
      console.error("Gagal mengirim Test Push:", err);
      res.status(500).json({ error: `Gagal mengirim push: ${err.message}` });
    }
  });

  // AI Proxy Routes
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      const ai = getAI();
      
      const contents = [
        ...history.map((h: any) => ({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: h.content }],
        })),
        { role: 'user', parts: [{ text: message }] }
      ];

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents,
        config: {
          systemInstruction: "Anda adalah tutor belajar yang ramah bernama Asisten Kuliah. Bantu mahasiswa memahami materi dengan gaya santai.",
        }
      });

      res.json({ text: response.text });
    } catch (error) {
      console.error("AI Chat Error:", error);
      res.status(500).json({ error: "AI Tutor sedang sibuk. Coba sesaat lagi." });
    }
  });

  app.post("/api/ai/scan", async (req, res) => {
    try {
      const { image, mimeType } = req.body; // base64 & MIME type
      const ai = getAI();
      const finalMimeType = mimeType || "image/jpeg";

      const prompt = `Ini adalah foto catatan tulisan tangan dari kuliah atau tangkapan layar buku materi. 
      Tolong lakukan OCR (pembacaan teks) dengan sangat teliti dan detail. Jangan lewatkan kata ataupun rumus penting. Setelah dibaca, buatkan rangkuman terstruktur dan penjelasan materi dengan bahasa yang ramah mahasiswa (bahasa santai di Indonesia). 
      Format output wajib menggunakan Markdown terstruktur seperti ini:
      # 📚 Judul Materi
      
      ## 📝 Rangkuman Materi Lengkap
      - [Poin penting 1]
      - [Poin penting 2]
      
      ## 🔍 Penjelasan Detail & Rumus (Bila ada)
      [Penjelasan mendalam di sini yang mudah dipahami]
      
      ## 💡 Daftar Istilah Kunci / Glosarium
      - **Istilah A**: Penjelasan sangat jelas dan mudah dipahami
      - **Istilah B**: Penjelasan sangat jelas dan mudah dipahami
      
      ## 🎯 Tips Belajar & Penerapan Praktis
      [Kasih saran bagaimana cara belajar materi ini agar cepat hafal/paham, dan contoh penerapannya di dunia nyata]`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: {
          parts: [
            { inlineData: { data: image, mimeType: finalMimeType } },
            { text: prompt }
          ]
        }
      });
      
      res.json({ text: response.text });
    } catch (error: any) {
      console.error("AI Scan Error:", error);
      res.status(500).json({ error: `Gagal memindai gambar: ${error.message || 'Error tidak diketahui'}` });
    }
  });

  // API Routes for Rating
  app.post("/api/rate", async (req, res) => {
    try {
      const { rating, userName } = req.body;
      
      console.log(`Rating received: ${rating} stars from ${userName || 'Anonymous'}`);

      const emailUser = process.env.EMAIL_USER;
      const emailPass = process.env.EMAIL_PASS;

      if (!emailUser || !emailPass) {
        console.warn("Email credentials not found. Notification skipped.");
        return res.json({ 
          success: true, 
          message: "Rating saved locally, but email notification was not configured." 
        });
      }

      const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: emailUser,
          pass: emailPass,
        },
      });

      const mailOptions = {
        from: `"AI Study Buddy" <${emailUser}>`,
        to: "saifulanamahmad352@gmail.com",
        subject: "🎉 Rating Baru Masuk!",
        html: `
          <div style="font-family: sans-serif; padding: 20px; color: #333; max-width: 600px; border: 1px solid #eee; border-radius: 12px;">
            <h2 style="color: #0ea5e9;">Ada Rating Baru! ⭐</h2>
            <p>Halo,</p>
            <p>Seseorang baru saja memberikan rating pada aplikasi Anda:</p>
            <div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0;"><strong>Rating:</strong> ${rating} / 5 Bintang</p>
              <p style="margin: 5px 0 0 0;"><strong>User:</strong> ${userName || 'Pengguna Anonim'}</p>
            </div>
            <p style="font-size: 11px; color: #999;">Email otomatis dari Server Asisten Kuliah.</p>
          </div>
        `,
      };

      await transporter.sendMail(mailOptions);
      res.json({ success: true });
    } catch (error) {
      console.error("Error in /api/rate:", error);
      res.status(500).json({ success: false, error: "Gagal memproses rating." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
