import express from "express";
import { GoogleGenAI } from "@google/genai";
import nodemailer from "nodemailer";
import cors from "cors";

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(cors());

// AI Setup
const getAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is missing in server environment");
  }
  return new GoogleGenAI({ apiKey });
};

// AI Proxy Routes
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    const ai = getAI();
    
    const contents = [
      ...history.map((h: any) => ({
        role: h.role === 'user' ? 'user' : 'model',
        parts: [{ text: h.content }],
      })),
      { role: 'user', parts: [{ text: message }] }
    ];

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents,
      config: {
        systemInstruction: "Anda adalah tutor belajar yang ramah bernama Asisten Kuliah. Bantu mahasiswa memahami materi dengan gaya santai.",
      }
    });

    res.json({ text: response.text });
  } catch (error) {
    console.error("AI Chat Error:", error);
    res.status(500).json({ error: "AI Tutor sedang sibuk. Coba sesaat lagi." });
  }
});

app.post("/api/ai/scan", async (req, res) => {
  try {
    const { image } = req.body;
    const ai = getAI();

    const prompt = `Ini adalah foto catatan tulisan tangan dari kuliah. 
    Tolong lakukan OCR (pembacaan teks) dan buatkan rangkuman poin-poin pentingnya dengan bahasa yang sederhana.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { inlineData: { data: image, mimeType: "image/jpeg" } },
          { text: prompt }
        ]
      }
    });
    
    res.json({ text: response.text });
  } catch (error) {
    console.error("AI Scan Error:", error);
    res.status(500).json({ error: "Gagal memindai gambar." });
  }
});

// Rating Route
app.post("/api/rate", async (req, res) => {
  try {
    const { rating, userName } = req.body;
    const emailUser = process.env.EMAIL_USER;
    const emailPass = process.env.EMAIL_PASS;

    if (emailUser && emailPass) {
      const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: { user: emailUser, pass: emailPass },
      });

      await transporter.sendMail({
        from: `"AI Study Buddy" <${emailUser}>`,
        to: "saifulanamahmad352@gmail.com",
        subject: "🎉 Rating Baru!",
        text: `Rating: ${rating} dari ${userName || 'Anonim'}`
      });
    }
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false });
  }
});

export default app;
