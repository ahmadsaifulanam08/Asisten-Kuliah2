/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Sidebar from './components/Sidebar';
import BottomNav from './components/BottomNav';
import Dashboard from './components/Dashboard';
import HandwritingScanner from './components/HandwritingScanner';
import MoodTracker from './components/MoodTracker';
import StudyCapacity from './components/StudyCapacity';
import { Sparkles, Bell, X, AlertTriangle, Share2, Clipboard, Check, ChevronDown, Database, Star, BarChart2, User, HelpCircle } from 'lucide-react';
import { Task, ScheduleItem, MoodEntry, ScheduleHistoryItem } from './types';

export default function App() {
  // Safe storage access helper
  const getSafeStorage = (key: string, defaultValue: string | null = null) => {
    try {
      return localStorage.getItem(key) || defaultValue;
    } catch (e) {
      console.warn(`Gagal mengakses localStorage untuk kunci: ${key}`, e);
      return defaultValue;
    }
  };

  const [activeTab, setActiveTab] = useState(() => getSafeStorage('asisten_activeTab', 'jadwal') || 'jadwal');
  const appName = 'Asisten Kuliah';
  const [userName, setUserName] = useState(() => {
    const val = getSafeStorage('asisten_userName', 'Mahasiswa');
    return val && val.trim() ? val : 'Mahasiswa';
  });
  const [aiName, setAiName] = useState(() => getSafeStorage('asisten_aiName', 'Sahabat AI') || 'Sahabat AI');
  const [isDarkMode, setIsDarkMode] = useState(() => getSafeStorage('asisten_isDarkMode') === 'true');
  const [avatar, setAvatar] = useState<string | null>(() => getSafeStorage('asisten_avatar'));
  const [expandedSection, setExpandedSection] = useState<string | null>('profil');
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => getSafeStorage('asisten_notifEnabled') === 'true');
  const [notificationDaysBefore, setNotificationDaysBefore] = useState(() => Number(getSafeStorage('asisten_notifDays', '1')));
  const [showNotifPanel, setShowNotifPanel] = useState(false);
  const [copied, setCopied] = useState(false);
  const [userRating, setUserRating] = useState<number>(0);
  const [showFeedbackMessage, setShowFeedbackMessage] = useState(false);
  const [isSubscribing, setIsSubscribing] = useState(false);

  // Conversion helper for VAPID base64 key to UInt8Array
  const urlBase64ToUint8Array = (base64String: string) => {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  };

  // Sync state parameters to server for push alerts
  const syncWithPushServer = async (customSub: any = null) => {
    try {
      let activeSub = customSub;
      if (!activeSub && 'serviceWorker' in navigator) {
        const reg = await navigator.serviceWorker.ready;
        activeSub = await reg.pushManager.getSubscription();
      }
      
      if (!activeSub) return;
      
      await fetch('/api/notifications/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subscription: activeSub,
          userName,
          aiName,
          notificationDaysBefore,
          tasks,
          schedule
        })
      });
    } catch (e) {
      console.warn('Gagal sinkronisasi data notifikasi dengan server:', e);
    }
  };

  // Register and subscribe to Push API
  const enableBackgroundNotifications = async () => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      alert('Perangkat Anda atau peramban ini belum mendukung API Notifikasi Latar Belakang.');
      return false;
    }

    setIsSubscribing(true);
    try {
      // 1. Request permission
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        alert('Izin notifikasi ditolak. Silakan aktifkan izin notifikasi di setelan browser HP Anda.');
        setIsSubscribing(false);
        return false;
      }

      // 2. Register Service Worker
      const reg = await navigator.serviceWorker.register('/sw.js');
      console.log('SW Registered:', reg);

      const readyReg = await navigator.serviceWorker.ready;

      // 3. Fetch VAPID key
      const keyRes = await fetch('/api/notifications/vapid-key');
      const { publicKey } = await keyRes.json();

      // 4. Subscribe
      const subscription = await readyReg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey)
      });

      console.log('Push subscription established:', subscription);
      
      // 5. Sync details with server instantly
      await syncWithPushServer(subscription);
      
      setNotificationsEnabled(true);
      setIsSubscribing(false);
      return true;
    } catch (err: any) {
      console.error('Error enabling push alerts:', err);
      alert(`Gagal mengonfigurasi Notifikasi Latar Belakang: ${err.message || err}`);
      setIsSubscribing(false);
      return false;
    }
  };



  const lastScrollTime = useRef(0);
  const [isScrollingFromNav, setIsScrollingFromNav] = useState(false);

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const sectionsRef = {
    jadwal: useRef<HTMLDivElement>(null),
    tugas: useRef<HTMLDivElement>(null),
    scan: useRef<HTMLDivElement>(null),
    mood: useRef<HTMLDivElement>(null),
  };
  const tabsOrder = ['jadwal', 'tugas', 'scan', 'mood'];

  const handleShare = async () => {
    const shareData = {
      title: appName,
      text: 'Cobain aplikasi Asisten Kuliah ini! Bantu banget buat atur jadwal dan manajemen tugas kuliah.',
      url: window.location.origin
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log('Share canceled or failed');
      }
    } else {
      navigator.clipboard.writeText(shareData.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };
  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem('asisten_tasks');
      return saved ? JSON.parse(saved) : [
        { id: '1', title: 'Tugas Kalkulus - Aljabar Linear', deadline: '2026-05-10', isCompleted: false, priority: 'high' },
        { id: '2', title: 'Rangkuman Materi Psikologi', deadline: '2026-05-12', isCompleted: true, priority: 'medium' },
        { id: '3', title: 'Laporan Praktikum Fisika Dasar', deadline: '2026-05-15', isCompleted: false, priority: 'medium' },
      ];
    } catch (e) {
      return [
        { id: '1', title: 'Tugas Kalkulus - Aljabar Linear', deadline: '2026-05-10', isCompleted: false, priority: 'high' },
        { id: '2', title: 'Rangkuman Materi Psikologi', deadline: '2026-05-12', isCompleted: true, priority: 'medium' },
        { id: '3', title: 'Laporan Praktikum Fisika Dasar', deadline: '2026-05-15', isCompleted: false, priority: 'medium' },
      ];
    }
  });
  const [schedule, setSchedule] = useState<ScheduleItem[]>(() => {
    try {
      const saved = localStorage.getItem('asisten_schedule');
      return saved ? JSON.parse(saved) : [
        { id: '1', title: 'Matematika Teknik', startTime: '08:00', endTime: '10:00', day: 'Senin', type: 'class' },
        { id: '2', title: 'Pemrograman Web', startTime: '10:30', endTime: '12:30', day: 'Senin', type: 'class' },
        { id: '3', title: 'Bahasa Inggris', startTime: '14:00', endTime: '16:00', day: 'Senin', type: 'class' },
      ];
    } catch (e) {
      return [
        { id: '1', title: 'Matematika Teknik', startTime: '08:00', endTime: '10:00', day: 'Senin', type: 'class' },
        { id: '2', title: 'Pemrograman Web', startTime: '10:30', endTime: '12:30', day: 'Senin', type: 'class' },
        { id: '3', title: 'Bahasa Inggris', startTime: '14:00', endTime: '16:00', day: 'Senin', type: 'class' },
      ];
    }
  });

  // Maintain Service Worker registration and sync changes dynamically
  useEffect(() => {
    if (notificationsEnabled) {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js').then(() => {
          syncWithPushServer();
        }).catch(err => {
          console.warn('Oto-registrasi SW gagal:', err);
        });
      }
    }
  }, [notificationsEnabled, tasks, schedule, userName, aiName, notificationDaysBefore]);

  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>(() => {
    try {
      const saved = localStorage.getItem('asisten_moodHistory');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [scheduleHistory, setScheduleHistory] = useState<ScheduleHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('asisten_scheduleHistory');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // Persistence effect with safety catch
  useEffect(() => {
    try {
      localStorage.setItem('asisten_userName', userName);
      localStorage.setItem('asisten_aiName', aiName);
      localStorage.setItem('asisten_isDarkMode', String(isDarkMode));
      localStorage.setItem('asisten_tasks', JSON.stringify(tasks));
      localStorage.setItem('asisten_schedule', JSON.stringify(schedule));
      localStorage.setItem('asisten_moodHistory', JSON.stringify(moodHistory));
      localStorage.setItem('asisten_scheduleHistory', JSON.stringify(scheduleHistory));
      localStorage.setItem('asisten_activeTab', activeTab);
      localStorage.setItem('asisten_notifEnabled', String(notificationsEnabled));
      localStorage.setItem('asisten_notifDays', String(notificationDaysBefore));
      if (avatar) {
        // Only save if it's within a reasonable size (e.g., < 1MB) to prevent quota errors
        if (avatar.length < 1000000) {
          localStorage.setItem('asisten_avatar', avatar);
        }
      } else {
        localStorage.removeItem('asisten_avatar');
      }
    } catch (e) {
      console.warn('Gagal menyimpan ke penyimpanan lokal (Memori penuh?):', e);
    }
  }, [userName, aiName, isDarkMode, tasks, schedule, moodHistory, scheduleHistory, activeTab, notificationsEnabled, notificationDaysBefore, avatar]);

  const [notifications, setNotifications] = useState<Task[]>([]);
  const [hasStartedVoice, setHasStartedVoice] = useState(false);

  const [showWelcome, setShowWelcome] = useState(true);

  useEffect(() => {
    // Hide visual greeting after some time
    const timer = setTimeout(() => setShowWelcome(false), 5000);
    return () => clearTimeout(timer);
  }, []);

  // Voice Greeting
  const speakGreeting = () => {
    if (window.speechSynthesis) {
      const displayableName = userName.trim() || 'Mahasiswa';
      const utterance = new SpeechSynthesisUtterance(`Halo ${displayableName}, selamat datang kembali di ${appName}. Siap produktif hari ini?`);
      utterance.lang = 'id-ID';
      utterance.rate = 1;
      utterance.pitch = 1.1;
      window.speechSynthesis.speak(utterance);
      setHasStartedVoice(true);
    }
  };

  useEffect(() => {
    // We try to speak, but browsers usually block this until first interaction
    // So we'll also trigget it on the first click if it hasn't run yet
    const handleFirstClick = () => {
      if (!hasStartedVoice) {
        speakGreeting();
      }
      window.removeEventListener('click', handleFirstClick);
    };
    window.addEventListener('click', handleFirstClick);
    return () => window.removeEventListener('click', handleFirstClick);
  }, [hasStartedVoice]);

  // Check for upcoming schedule items every minute
  useEffect(() => {
    if (!notificationsEnabled || !('Notification' in window)) return;

    const checkInterval = setInterval(() => {
      const now = new Date();
      // For demo purposes, we'll use a mocked "current day" if it's the first time
      // But in reality, we use real now.getDay()
      const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
      const currentDay = dayNames[now.getDay()];
      const currentTime = now.getHours() * 60 + now.getMinutes();

      schedule.forEach(item => {
        if (item.day === currentDay) {
          const [hours, minutes] = item.startTime.split(':').map(Number);
          const startTimeInMinutes = hours * 60 + minutes;
          
          // Notify 5 minutes before
          if (startTimeInMinutes - currentTime === 5 && Notification.permission === 'granted') {
            new Notification(`Pengingat: ${item.title}`, {
              body: `Kelas/Kegiatan akan dimulai jam ${item.startTime}! Bersiaplah.`,
              icon: '/favicon.svg'
            });
          }
        }
      });

      // Also check tasks due according to preference at 8 AM
      if (now.getHours() === 8 && now.getMinutes() === 0) {
        const targetDate = new Date(now);
        targetDate.setDate(targetDate.getDate() + notificationDaysBefore);
        const targetDateStr = targetDate.toISOString().split('T')[0];
        
        const dueSoon = tasks.filter(t => !t.isCompleted && t.deadline === targetDateStr);
        if (dueSoon.length > 0 && Notification.permission === 'granted') {
          new Notification(notificationDaysBefore === 1 ? 'Deadline Tugas Besok!' : `Deadline Tugas ${notificationDaysBefore} Hari Lagi!`, {
            body: `Ada ${dueSoon.length} tugas yang harus dikumpulkan ${notificationDaysBefore === 1 ? 'besok' : `${notificationDaysBefore} hari lagi`}. Cek sekarang!`,
            icon: '/favicon.svg'
          });
        }
      }
    }, 60000); // Every minute

    return () => clearInterval(checkInterval);
  }, [schedule, tasks, notificationsEnabled, notificationDaysBefore]);

  // Check for upcoming deadlines for UI display
  useEffect(() => {
    const today = new Date('2026-05-09'); // Mocking today's date based on metadata
    const upcomingTasks = tasks.filter(task => {
      if (task.isCompleted) return false;
      const deadlineDate = new Date(task.deadline);
      const diffTime = deadlineDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 && diffDays <= notificationDaysBefore;
    });
    setNotifications(upcomingTasks);
  }, [tasks, notificationDaysBefore]);

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, isCompleted: !t.isCompleted } : t));
  };

  const addTask = (task: Omit<Task, 'id' | 'isCompleted'>) => {
    const newTask: Task = {
      ...task,
      id: Math.random().toString(36).substr(2, 9),
      isCompleted: false,
    };
    setTasks([...tasks, newTask]);
  };

  const removeTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const addSchedule = (item: Omit<ScheduleItem, 'id'>) => {
    const newItem: ScheduleItem = {
      ...item,
      id: Math.random().toString(36).substr(2, 9),
    };
    setSchedule([...schedule, newItem]);

    // Track in scheduleHistory
    const histItem: ScheduleHistoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      actionType: 'add',
      description: `Menambahkan kelas "${newItem.title}" (${newItem.day}, ${newItem.startTime} - ${newItem.endTime})`,
      newSchedule: newItem,
    };
    setScheduleHistory(prev => [histItem, ...prev]);
  };

  const removeSchedule = (id: string) => {
    const oldItem = schedule.find(s => s.id === id);
    if (!oldItem) return;
    setSchedule(schedule.filter(s => s.id !== id));

    // Track in scheduleHistory
    const histItem: ScheduleHistoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      actionType: 'delete',
      description: `Menghapus kelas "${oldItem.title}" (${oldItem.day}, ${oldItem.startTime} - ${oldItem.endTime})`,
      oldSchedule: oldItem,
    };
    setScheduleHistory(prev => [histItem, ...prev]);
  };

  const updateSchedule = (updatedItem: ScheduleItem) => {
    const oldItem = schedule.find(s => s.id === updatedItem.id);
    if (!oldItem) return;
    
    setSchedule(schedule.map(s => s.id === updatedItem.id ? updatedItem : s));

    // Track in scheduleHistory
    const histItem: ScheduleHistoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      actionType: 'edit',
      description: `Mengubah kelas "${oldItem.title}" menjadi "${updatedItem.title}" (${updatedItem.day}, ${updatedItem.startTime} - ${updatedItem.endTime})`,
      oldSchedule: oldItem,
      newSchedule: updatedItem,
    };
    setScheduleHistory(prev => [histItem, ...prev]);
  };

  const restoreScheduleHistory = (historyItem: ScheduleHistoryItem) => {
    if (historyItem.actionType === 'add') {
      if (historyItem.newSchedule) {
        setSchedule(prev => prev.filter(s => s.id !== historyItem.newSchedule?.id));
      }
    } else if (historyItem.actionType === 'delete') {
      if (historyItem.oldSchedule) {
        setSchedule(prev => [...prev, historyItem.oldSchedule!]);
      }
    } else if (historyItem.actionType === 'edit') {
      if (historyItem.oldSchedule) {
        setSchedule(prev => prev.map(s => s.id === historyItem.oldSchedule?.id ? historyItem.oldSchedule! : s));
      }
    }

    const restorationLog: ScheduleHistoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      actionType: 'restore',
      description: `Memulihkan riwayat: ${historyItem.description}`,
    };
    
    // Add restoration log, filter out target restored history item
    setScheduleHistory(prev => [restorationLog, ...prev.filter(h => h.id !== historyItem.id)]);
  };

  const addMoodEntry = (entry: Omit<MoodEntry, 'id'>) => {
    const newEntry: MoodEntry = {
      ...entry,
      id: Math.random().toString(36).substr(2, 9),
    };
    setMoodHistory([newEntry, ...moodHistory]);
  };

  const removeMoodEntry = (id: string) => {
    setMoodHistory(moodHistory.filter(m => m.id !== id));
  };

  // Handle Tab Change
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'settings') return;

    const ref = sectionsRef[tab as keyof typeof sectionsRef];
    if (ref && ref.current && scrollContainerRef.current) {
      setIsScrollingFromNav(true);
      ref.current.scrollIntoView({ behavior: 'auto', block: 'start' });
      
      // Reset the lock after animation roughly finishes
      setTimeout(() => setIsScrollingFromNav(false), 100);
    }
  };

  // Intersection Observer to sync scroll position with active tab
  useEffect(() => {
    if (activeTab === 'settings') return;

    const options = {
      root: scrollContainerRef.current,
      rootMargin: '-20% 0px -70% 0px',
      threshold: 0
    };

    const callback = (entries: IntersectionObserverEntry[]) => {
      if (isScrollingFromNav) return;

      entries.forEach(entry => {
        if (entry.isIntersecting) {
          setActiveTab(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(callback, options);

    Object.values(sectionsRef).forEach(ref => {
      if (ref.current) observer.observe(ref.current);
    });

    return () => observer.disconnect();
  }, [isScrollingFromNav, activeTab]);

  const renderContent = () => {
    if (activeTab === 'settings') {
      return (
        <div className="max-w-xl mx-auto space-y-3 pb-6 overflow-y-auto h-full pr-1">
          {/* Header */}
          <div className="flex flex-col gap-0.5 mb-2.5 select-none">
            <h2 className={`text-2xl font-extrabold tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Pengaturan</h2>
            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Pilih menu di bawah untuk kustomisasi profil, tampilan, notifikasi, dan pengelolaan data.
            </p>
          </div>

          <div className="space-y-2">
            {/* 1. Detail Profil */}
            <div className={`rounded-2xl border transition-all overflow-hidden ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} shadow-sm`}>
              <button 
                onClick={() => setExpandedSection(expandedSection === 'profil' ? null : 'profil')}
                className="w-full flex items-center justify-between p-3.5 px-4 text-left outline-none cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-xl ${isDarkMode ? 'bg-slate-700/50' : 'bg-sky-50'}`}>
                    <User size={18} className="text-ocean" />
                  </div>
                  <div>
                    <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Detail Profil</h4>
                    <p className={`text-[9px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Atur nama panggilan kamu dan sebutan untuk Sahabat AI</p>
                  </div>
                </div>
                <ChevronDown size={15} className={`text-slate-400 transform transition-transform duration-300 ${expandedSection === 'profil' ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence initial={false}>
                {expandedSection === 'profil' && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="border-t border-slate-100 dark:border-slate-750 p-4 bg-slate-50/30 dark:bg-slate-900/10 space-y-4"
                  >
                    {/* Profile/Avatar Section */}
                    <div className="flex items-center gap-4 pb-4 border-b border-slate-100 dark:border-slate-750">
                      <div className="relative group flex-shrink-0">
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white text-xl font-bold shadow-md overflow-hidden border-2 border-white ${isDarkMode ? 'bg-slate-700 dark:border-slate-800' : 'bg-ocean'}`}>
                          {avatar ? (
                            <img src={avatar} alt="Avatar Preview" className="w-full h-full object-cover" />
                          ) : (
                            <img 
                              src="https://api.dicebear.com/7.x/avataaars/svg?seed=Saiful" 
                              alt="Default Avatar"
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>
                        <label className="absolute -bottom-1 -right-1 p-1 bg-white dark:bg-slate-750 rounded-lg shadow-md border border-slate-100 dark:border-slate-600 cursor-pointer hover:scale-110 transition-all z-10">
                          <Sparkles size={12} className="text-ocean animate-pulse" />
                          <input 
                            type="file" 
                            className="hidden" 
                            accept="image/*" 
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onload = (event) => {
                                  const img = new Image();
                                  img.onload = () => {
                                    const canvas = document.createElement('canvas');
                                    const maxDim = 120;
                                    let width = img.width;
                                    let height = img.height;
                                    if (width > height) {
                                      if (width > maxDim) {
                                        height *= maxDim / width;
                                        width = maxDim;
                                      }
                                    } else {
                                      if (height > maxDim) {
                                        width *= maxDim / height;
                                        height = maxDim;
                                      }
                                    }
                                    canvas.width = width;
                                    canvas.height = height;
                                    const ctx = canvas.getContext('2d');
                                    if (ctx) {
                                      ctx.drawImage(img, 0, 0, width, height);
                                      const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
                                      setAvatar(compressedBase64);
                                      try {
                                        localStorage.setItem('asisten_avatar', compressedBase64);
                                      } catch (storageError) {
                                        console.error("Gagal melestarikan foto profil secara instan:", storageError);
                                      }
                                    }
                                  };
                                  img.src = event.target?.result as string;
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                      </div>
                      <div className="text-left">
                        <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{userName.trim() || 'Mahasiswa'}</h4>
                        <p className="text-slate-400 text-[9px] italic">Klik ikon bintang kecil di atas untuk mengubah foto profil (tersimpan otomatis)</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className={`block text-[9px] font-bold uppercase tracking-wider mb-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Nama Kamu</label>
                        <input 
                          type="text" 
                          value={userName}
                          onChange={(e) => setUserName(e.target.value)}
                          className={`w-full p-2.5 text-xs rounded-xl border outline-none focus:border-ocean transition-all ${isDarkMode ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-100 text-slate-800'}`}
                          placeholder="Masukkan nama kamu..."
                        />
                      </div>

                      <div>
                        <label className={`block text-[9px] font-bold uppercase tracking-wider mb-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Nama AI (Tutor)</label>
                        <input 
                          type="text" 
                          value={aiName}
                          onChange={(e) => setAiName(e.target.value)}
                          className={`w-full p-2.5 text-xs rounded-xl border outline-none focus:border-ocean transition-all ${isDarkMode ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50 border-slate-100 text-slate-800'}`}
                          placeholder="Beri nama untuk AI Tutor kamu..."
                        />
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 2. Tampilan Aplikasi */}
            <div className={`rounded-2xl border transition-all overflow-hidden ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} shadow-sm`}>
              <button 
                onClick={() => setExpandedSection(expandedSection === 'tampilan' ? null : 'tampilan')}
                className="w-full flex items-center justify-between p-3.5 px-4 text-left outline-none cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-xl ${isDarkMode ? 'bg-slate-700/50' : 'bg-sky-50'}`}>
                    <Sparkles size={18} className="text-ocean" />
                  </div>
                  <div>
                    <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Tampilan Aplikasi</h4>
                    <p className={`text-[9px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Kustomisasi mode gelap untuk kenyamanan mata</p>
                  </div>
                </div>
                <ChevronDown size={15} className={`text-slate-400 transform transition-transform duration-300 ${expandedSection === 'tampilan' ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence initial={false}>
                {expandedSection === 'tampilan' && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="border-t border-slate-100 dark:border-slate-755 p-4 bg-slate-50/30 dark:bg-slate-900/10"
                  >
                    <div className="flex items-center justify-between p-1">
                      <div>
                        <h4 className={`text-xs font-bold ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Aktifkan Mode Gelap</h4>
                        <p className="text-[10px] text-slate-400">Gunakan tema warna gelap yang nyaman di mata</p>
                      </div>
                      <button 
                        onClick={() => setIsDarkMode(!isDarkMode)}
                        className={`w-10 h-6 bg-slate-200 dark:bg-slate-700 rounded-full p-0.5 transition-colors duration-300 flex items-center shrink-0 border border-transparent`}
                      >
                        <motion.div 
                          animate={{ x: isDarkMode ? 16 : 0, backgroundColor: isDarkMode ? '#00b4d8' : '#ffffff' }}
                          className="w-5 h-5 rounded-full shadow-sm"
                        />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 3. Pengaturan Notifikasi */}
            <div className={`rounded-2xl border transition-all overflow-hidden ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} shadow-sm`}>
              <button 
                onClick={() => setExpandedSection(expandedSection === 'notifikasi' ? null : 'notifikasi')}
                className="w-full flex items-center justify-between p-3.5 px-4 text-left outline-none cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-xl ${isDarkMode ? 'bg-slate-700/50' : 'bg-sky-50'}`}>
                    <Bell size={18} className="text-ocean" />
                  </div>
                  <div>
                    <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Notifikasi Latar Belakang</h4>
                    <p className={`text-[9px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Terima notifikasi jadwal tetap masuk saat aplikasi ditutup</p>
                  </div>
                </div>
                <ChevronDown size={15} className={`text-slate-400 transform transition-transform duration-300 ${expandedSection === 'notifikasi' ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence initial={false}>
                {expandedSection === 'notifikasi' && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="border-t border-slate-100 dark:border-slate-755 p-4 bg-slate-50/30 dark:bg-slate-900/10 space-y-3"
                  >
                    {/* Background Notification Toggle */}
                    <div className={`flex items-center justify-between p-3 rounded-xl border ${isDarkMode ? 'bg-slate-900/50 border-slate-800' : 'bg-sky-light/20 border-sky-100'}`}>
                      <div>
                        <h4 className="font-bold text-xs text-ocean">
                          Notifikasi Latar Belakang (HP & PC)
                        </h4>
                        <p className="text-[10px] text-slate-400">Aktifkan pengingat jadwal dan deadline</p>
                      </div>
                      <button 
                        disabled={isSubscribing}
                        onClick={async () => {
                          if (!notificationsEnabled) {
                            await enableBackgroundNotifications();
                          } else {
                            setNotificationsEnabled(false);
                            try {
                              if ('serviceWorker' in navigator) {
                                const reg = await navigator.serviceWorker.ready;
                                const sub = await reg.pushManager.getSubscription();
                                if (sub) {
                                  await sub.unsubscribe();
                                }
                              }
                            } catch (e) {
                              console.warn('Gagal unsubscribe push:', e);
                            }
                          }
                        }}
                        className={`w-10 h-6 bg-slate-200 dark:bg-slate-700 rounded-full p-0.5 transition-colors duration-300 flex items-center shrink-0 border border-transparent ${isSubscribing ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        <motion.div 
                          animate={{ x: notificationsEnabled ? 16 : 0, backgroundColor: notificationsEnabled ? '#00b4d8' : '#ffffff' }}
                          className="w-5 h-5 rounded-full shadow-sm"
                        />
                      </button>
                    </div>

                    {/* Status Info Badge */}
                    <div className={`p-3 rounded-xl border text-[11px] leading-relaxed ${notificationsEnabled ? (isDarkMode ? 'bg-emerald-950/20 border-emerald-800/50 text-emerald-300' : 'bg-emerald-50 border-emerald-100 text-emerald-800') : (isDarkMode ? 'bg-slate-900/80 border-slate-800 text-slate-400' : 'bg-slate-100/80 border-slate-200 text-slate-500')}`}>
                      <div className="flex items-center gap-1.5 mb-1 text-xs">
                        <span className={`w-2 h-2 rounded-full inline-block ${notificationsEnabled ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
                        <span className="font-bold">Status: {notificationsEnabled ? 'Aktif' : 'Nonaktif'}</span>
                      </div>
                      <p className="text-[10px]">
                        {notificationsEnabled 
                          ? "Sistem server akan terus menjadwalkan notifikasi kelas (5 menit sebelum mulai) dan info deadline tugas." 
                          : "Aktifkan tombol di atas untuk menghubungkan ponsel Anda dengan sistem notifikasi server secara instan."}
                      </p>
                    </div>

                    {/* Notification Days Selection */}
                    <div className={`p-3 rounded-xl border ${isDarkMode ? 'bg-slate-900/50 border-slate-800' : 'bg-sky-light/20 border-sky-100'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h4 className="font-bold text-xs text-ocean">Waktu Pengingat Deadline Tugas</h4>
                          <p className="text-[10px] text-slate-400">Notifikasi alarm dikirim H- sebelum deadline</p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <input 
                            type="number" 
                            min="1" 
                            max="30"
                            value={notificationDaysBefore}
                            onChange={(e) => {
                              const val = parseInt(e.target.value);
                              if (!isNaN(val) && val >= 1) {
                                setNotificationDaysBefore(val);
                              }
                            }}
                            className={`w-11 px-1.5 py-1 text-xs font-bold rounded-lg border text-center focus:ring-2 focus:ring-ocean outline-none ${
                              isDarkMode 
                              ? 'bg-slate-800 border-slate-700 text-white' 
                              : 'bg-white border-sky-200 text-slate-700'
                            }`}
                          />
                          <span className="text-[10px] font-bold text-slate-500">Hari</span>
                        </div>
                      </div>
                      <p className={`text-[9px] italic ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                        Sistem push server akan memicu pengingat {notificationDaysBefore} hari sebelum tugas jatuh tempo.
                      </p>
                    </div>

                    {/* Test push button */}
                    {notificationsEnabled && (
                      <button
                        onClick={async () => {
                          try {
                            if ('serviceWorker' in navigator) {
                              const reg = await navigator.serviceWorker.ready;
                              const sub = await reg.pushManager.getSubscription();
                              if (!sub) {
                                alert('Pastikan Anda sudah menyetujui izin notifikasi perangkat.');
                                return;
                              }
                              
                              const testRes = await fetch('/api/notifications/test-push', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ subscription: sub })
                              });
                              if (!testRes.ok) {
                                throw new Error('Post failed');
                              }
                              alert('Sinyal uji coba terkirim! Silakan cari notifikasi push di layar HP / PC Anda sekarang.');
                            }
                          } catch (e: any) {
                            alert(`Gagal mengirim ujicoba: ${e.message}`);
                          }
                        }}
                        className="w-full py-2 bg-sky-500/10 hover:bg-sky-500/20 text-sky-600 dark:text-sky-400 font-bold rounded-xl text-[11px] transition-colors flex items-center justify-center gap-1.5 border border-sky-500/10 cursor-pointer"
                      >
                        ⚡ Uji Coba Kirim Notifikasi Sekarang
                      </button>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 4. Penyimpanan & Backup */}
            <div className={`rounded-2xl border transition-all overflow-hidden ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} shadow-sm`}>
              <button 
                onClick={() => setExpandedSection(expandedSection === 'database' ? null : 'database')}
                className="w-full flex items-center justify-between p-3.5 px-4 text-left outline-none cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-xl ${isDarkMode ? 'bg-slate-700/50' : 'bg-sky-50'}`}>
                    <Database size={18} className="text-ocean" />
                  </div>
                  <div>
                    <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Penyimpanan & Cadangan Data</h4>
                    <p className={`text-[9px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Ekspor file backup cadangan lokal & kelola database privat</p>
                  </div>
                </div>
                <ChevronDown size={15} className={`text-slate-400 transform transition-transform duration-300 ${expandedSection === 'database' ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence initial={false}>
                {expandedSection === 'database' && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="border-t border-slate-100 dark:border-slate-755 p-4 bg-slate-50/30 dark:bg-slate-900/10 space-y-3"
                  >
                    <div className={`p-3 rounded-2xl border border-dashed ${isDarkMode ? 'bg-amber-950/10 border-amber-500/30' : 'bg-amber-50 border-amber-200'}`}>
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Database size={14} className="text-amber-500" />
                        <h4 className={`font-bold text-[11px] ${isDarkMode ? 'text-amber-200' : 'text-amber-900'}`}>Informasi Database</h4>
                      </div>
                      <div className="space-y-2">
                        <p className={`text-[10px] leading-relaxed ${isDarkMode ? 'text-amber-300/70' : 'text-amber-700'}`}>
                          <b>Status:</b> Penyimpanan Lokal (Offline & Privat).
                        </p>
                        <p className={`text-[10px] leading-relaxed ${isDarkMode ? 'text-amber-300/70' : 'text-amber-700'}`}>
                          <b>Risiko:</b> Jika cache browser dibersihkan, data aplikasi Anda akan hilang. Silakan buat cadangan lokal.
                        </p>
                        <div className="pt-1 flex flex-col sm:flex-row gap-2">
                          <button 
                            onClick={() => {
                              const data = { userName, tasks, schedule, aiName, avatar };
                              const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
                              const url = URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `backup-${userName}-${new Date().toLocaleDateString()}.json`;
                              a.click();
                            }}
                            className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-white text-[10px] font-bold rounded-lg transition-colors flex items-center justify-center gap-1 shadow-sm cursor-pointer"
                          >
                            💾 Ekspor Backup
                          </button>
                          <button 
                            onClick={() => {
                              if (confirm('Apakah Anda yakin ingin menghapus semua data dan mengatur ulang ke setelan pabrik?')) {
                                localStorage.clear();
                                window.location.reload();
                              }
                            }}
                            className={`px-3 py-2 text-[10px] font-bold rounded-lg border transition-colors flex items-center justify-center gap-1 cursor-pointer ${isDarkMode ? 'border-amber-500/30 text-amber-500 hover:bg-amber-500/10' : 'border-amber-200 text-amber-600 hover:bg-amber-100'}`}
                          >
                            🗑️ Reset Semua Data
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 5. Bagikan Aplikasi */}
            <div className={`rounded-2xl border transition-all overflow-hidden ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} shadow-sm`}>
              <button 
                onClick={() => setExpandedSection(expandedSection === 'share' ? null : 'share')}
                className="w-full flex items-center justify-between p-3.5 px-4 text-left outline-none cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-xl ${isDarkMode ? 'bg-slate-700/50' : 'bg-sky-50'}`}>
                    <Share2 size={18} className="text-ocean" />
                  </div>
                  <div>
                    <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Bagikan Aplikasi</h4>
                    <p className={`text-[9px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Ajak teman kuliahmu memakai asisten ini dan belajar bareng!</p>
                  </div>
                </div>
                <ChevronDown size={15} className={`text-slate-400 transform transition-transform duration-300 ${expandedSection === 'share' ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence initial={false}>
                {expandedSection === 'share' && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="border-t border-slate-100 dark:border-slate-755 p-4 bg-slate-50/30 dark:bg-slate-900/10 space-y-3"
                  >
                    <div className={`p-3 rounded-xl border-2 border-dashed ${isDarkMode ? 'bg-slate-900 border-ocean/30 text-slate-300' : 'bg-sky-50 border-sky-200 text-slate-700'}`}>
                      <div className="flex gap-2 items-start">
                        <div className="w-4 h-4 bg-ocean text-white rounded-full flex items-center justify-center text-[9px] font-bold shrink-0 mt-0.5">!</div>
                        <div className="text-[10px] space-y-1">
                          <p className="font-bold text-ocean">Info Akses Pengguna Lain:</p>
                          <p>Buka tombol <b>Share</b> di pojok kanan atas AI Studio Workspace Anda, lalu salin "Shared URL".</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className={`p-2 rounded-xl flex items-center justify-between gap-2.5 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'} border`}>
                      <code className="text-[9px] md:text-xs text-ocean font-bold truncate">
                        {window.location.origin}
                      </code>
                      <button 
                        onClick={handleShare}
                        className={`shrink-0 p-1.5 rounded-lg transition-all cursor-pointer ${copied ? 'bg-emerald-500 text-white' : 'hover:bg-ocean/10 text-ocean'}`}
                      >
                        {copied ? <Check size={14} /> : <Clipboard size={14} />}
                      </button>
                    </div>

                    <motion.button 
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      onClick={handleShare}
                      className="w-full py-2 bg-ocean text-white rounded-xl font-bold shadow-md shadow-ocean/20 flex items-center justify-center gap-1.5 text-[11px] cursor-pointer"
                    >
                      <Share2 size={14} />
                      Bagikan Link Sekarang
                    </motion.button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 6. Rating & Feedback */}
            <div className={`rounded-2xl border transition-all overflow-hidden ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} shadow-sm`}>
              <button 
                onClick={() => setExpandedSection(expandedSection === 'rating' ? null : 'rating')}
                className="w-full flex items-center justify-between p-3.5 px-4 text-left outline-none cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-xl ${isDarkMode ? 'bg-slate-700/50' : 'bg-sky-50'}`}>
                    <Star size={18} className="text-ocean" />
                  </div>
                  <div>
                    <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Rating & Feedback</h4>
                    <p className={`text-[9px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Berikan 5 bintang & masukan konstruktif untuk pengembang</p>
                  </div>
                </div>
                <ChevronDown size={15} className={`text-slate-400 transform transition-transform duration-300 ${expandedSection === 'rating' ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence initial={false}>
                {expandedSection === 'rating' && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="border-t border-slate-100 dark:border-slate-755 p-4 bg-slate-50/30 dark:bg-slate-900/10 text-center"
                  >
                    <AnimatePresence mode="wait">
                      {!showFeedbackMessage ? (
                        <motion.div 
                          key="rating-input"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="space-y-3"
                        >
                          <p className="text-slate-400 text-xs">Bagaimana kesan Anda setelah memakai {appName}?</p>
                          <div className="flex justify-center gap-1.5">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <motion.button
                                key={star}
                                whileHover={{ scale: 1.15 }}
                                whileTap={{ scale: 0.95 }}
                                onMouseEnter={() => !userRating && setUserRating(star)}
                                onMouseLeave={() => !showFeedbackMessage && userRating === star && setUserRating(0)}
                                onClick={async () => {
                                  const selectedRating = star;
                                  setUserRating(selectedRating);
                                  
                                  try {
                                    const res = await fetch('/api/rate', {
                                      method: 'POST',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ 
                                        rating: selectedRating,
                                        userName: userName 
                                      }),
                                    });
                                    
                                    if (res.ok) {
                                      setShowFeedbackMessage(true);
                                    } else {
                                      throw new Error('Server error');
                                    }
                                  } catch (error) {
                                    console.error("Gagal mengirim notifikasi rating:", error);
                                    setShowFeedbackMessage(true);
                                  }
                                }}
                                className={`text-2xl transition-colors duration-200 cursor-pointer ${
                                  (userRating >= star) ? 'text-amber-400' : 'text-slate-200'
                                }`}
                              >
                                <Star className="w-6 h-6" fill={userRating >= star ? 'currentColor' : 'none'} />
                              </motion.button>
                            ))}
                          </div>
                        </motion.div>
                      ) : (
                        <motion.div 
                          key="feedback-message"
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="py-2"
                        >
                          <div className="bg-ocean/10 text-ocean rounded-xl p-3 inline-block mb-2">
                            <Sparkles className="w-6 h-6 mx-auto mb-1" />
                            <p className="font-bold text-xs">Terima kasih atas rating {userRating} bintangnya!</p>
                          </div>
                          <p className={`text-[10px] ${isDarkMode ? 'text-slate-300' : 'text-slate-500'}`}>
                            Kritik dan saran Anda sangat membantu kami dalam menyempurnakan aplikasi ini. Laporan bintang terkirim ke server.
                          </p>
                          <button 
                            onClick={() => {
                              setShowFeedbackMessage(false);
                              setUserRating(0);
                            }}
                            className="mt-2 text-[10px] text-ocean hover:underline font-bold cursor-pointer"
                          >
                            Beri rating lagi
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 7. Panduan Instal App */}
            <div className={`rounded-2xl border transition-all overflow-hidden ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} shadow-sm`}>
              <button 
                onClick={() => setExpandedSection(expandedSection === 'guide' ? null : 'guide')}
                className="w-full flex items-center justify-between p-3.5 px-4 text-left outline-none cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-xl ${isDarkMode ? 'bg-slate-700/50' : 'bg-sky-50'}`}>
                    <HelpCircle size={18} className="text-ocean" />
                  </div>
                  <div>
                    <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Petunjuk Instalasi (HP & Komputer)</h4>
                    <p className={`text-[9px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Cara menyimpan Asisten Kuliah di beranda utama ponsel</p>
                  </div>
                </div>
                <ChevronDown size={15} className={`text-slate-400 transform transition-transform duration-300 ${expandedSection === 'guide' ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence initial={false}>
                {expandedSection === 'guide' && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="border-t border-slate-100 dark:border-slate-755 p-4 bg-slate-50/30 dark:bg-slate-900/10"
                  >
                    <div className={`space-y-3 text-[11px] ${isDarkMode ? 'text-slate-300' : 'text-slate-500'}`}>
                      <div className="flex gap-2.5">
                        <div className="w-5 h-5 rounded-full bg-ocean text-white flex items-center justify-center flex-shrink-0 text-[9px] font-bold">1</div>
                        <p>Buka link aplikasi ini menggunakan browser (Google Chrome / Safari).</p>
                      </div>
                      <div className="flex gap-2.5">
                        <div className="w-5 h-5 rounded-full bg-ocean text-white flex items-center justify-center flex-shrink-0 text-[9px] font-bold">2</div>
                        <p>Ketuk tombol menu browser (titik tiga atau tombol Share di Safari).</p>
                      </div>
                      <div className="flex gap-2.5">
                        <div className="w-5 h-5 rounded-full bg-ocean text-white flex items-center justify-center flex-shrink-0 text-[9px] font-bold">3</div>
                        <p>Pilih opsi <b>"Instal Aplikasi"</b> atau <b>"Tambahkan ke Layar Utama"</b>.</p>
                      </div>
                      <p className="pt-1 text-ocean italic font-bold">Selesai! Kini dapat diakses langsung dari beranda.</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 8. Lapor Masalah */}
            <div className={`rounded-2xl border transition-all overflow-hidden ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'} shadow-sm`}>
              <button 
                onClick={() => setExpandedSection(expandedSection === 'bug' ? null : 'bug')}
                className="w-full flex items-center justify-between p-3.5 px-4 text-left outline-none cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`p-1.5 rounded-xl ${isDarkMode ? 'bg-slate-700/50' : 'bg-sky-50'}`}>
                    <AlertTriangle size={18} className="text-ocean" />
                  </div>
                  <div>
                    <h4 className={`font-bold text-xs ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Lapor Bug / Masalah</h4>
                    <p className={`text-[9px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Kirim error, tombol macet, atau laporan masalah ke pengembang</p>
                  </div>
                </div>
                <ChevronDown size={15} className={`text-slate-400 transform transition-transform duration-300 ${expandedSection === 'bug' ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence initial={false}>
                {expandedSection === 'bug' && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="border-t border-slate-100 dark:border-slate-755 p-4 bg-slate-50/30 dark:bg-slate-900/10 space-y-3"
                  >
                    <p className={`text-[11px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      Jika menemukan error, tombol yang tidak aktif, atau fitur yang lambat, segera kirim laporan kepada kami.
                    </p>
                    <a 
                      href="mailto:saifulanamahmad352@gmail.com?subject=Laporan Bug Asisten Kuliah&body=Halo Saiful,%0D%0A%0D%0ASaya menemukan masalah pada aplikasi: %0D%0A(Jelaskan masalah di sini...)"
                      className="block w-full py-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-bold text-center shadow-md dark:shadow-none transition-all text-xs cursor-pointer"
                    >
                      Kirim Laporan ke Email
                    </a>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Development Banner Footer */}
          <div className={`p-3 rounded-2xl border text-center ${isDarkMode ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-100/50 border-slate-200'}`}>
            <p className="text-slate-400 text-[9px]">Versi 1.1.5 • Dibuat dengan ❤️ untuk mahasiswa seluruh Indonesia</p>
          </div>
        </div>
      );
    }

    if (activeTab === 'jadwal') {
      return (
        <div className="space-y-6">
          <Dashboard 
            tasks={[]} 
            toggleTask={() => {}} 
            removeTask={() => {}} 
            addTask={() => {}} 
            schedule={schedule}
            addSchedule={addSchedule}
            removeSchedule={removeSchedule}
            updateSchedule={updateSchedule}
            scheduleHistory={scheduleHistory}
            restoreScheduleHistory={restoreScheduleHistory}
            clearScheduleHistory={() => setScheduleHistory([])}
            isDarkMode={isDarkMode} 
            showOnly="jadwal"
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <motion.div 
              whileHover={{ scale: 1.02 }}
              onClick={() => handleTabChange('kapasitas')}
              className={`p-6 rounded-3xl border cursor-pointer group transition-all ${isDarkMode ? 'bg-indigo-900/10 border-indigo-900/20' : 'bg-indigo-50 border-indigo-100'}`}
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white">
                  <BarChart2 size={20} />
                </div>
                <h3 className={`font-bold ${isDarkMode ? 'text-indigo-200' : 'text-indigo-900'}`}>Kapasitas Belajar</h3>
              </div>
              <p className={`text-xs ${isDarkMode ? 'text-indigo-300/70' : 'text-indigo-700'}`}>Ukur performa harian, tingkat fokus kognitif, dan tren waktu belajar.</p>
            </motion.div>

            <motion.div 
              whileHover={{ scale: 1.02 }}
              onClick={() => handleTabChange('tugas')}
              className={`p-6 rounded-3xl border cursor-pointer transition-all ${isDarkMode ? 'bg-emerald-900/10 border-emerald-900/20' : 'bg-emerald-50 border-emerald-100'}`}
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center text-white">
                  <Check size={23} />
                </div>
                <h3 className={`font-bold ${isDarkMode ? 'text-emerald-200' : 'text-emerald-900'}`}>Kelola Tugas</h3>
              </div>
              <p className={`text-xs ${isDarkMode ? 'text-emerald-300/70' : 'text-emerald-700'}`}>Lihat {tasks.filter(t => !t.isCompleted).length} tugas yang belum selesai.</p>
            </motion.div>
          </div>
        </div>
      );
    }

    if (activeTab === 'tugas') {
      return (
        <Dashboard 
          tasks={tasks} 
          toggleTask={toggleTask} 
          removeTask={removeTask} 
          addTask={addTask} 
          schedule={[]} 
          addSchedule={() => {}}
          removeSchedule={() => {}}
          isDarkMode={isDarkMode} 
          showOnly="tugas"
        />
      );
    }

    if (activeTab === 'scan') return <HandwritingScanner isDarkMode={isDarkMode} />;
    if (activeTab === 'mood') return (
      <MoodTracker 
        isDarkMode={isDarkMode} 
        aiName={aiName} 
        moodHistory={moodHistory} 
        onAddEntry={addMoodEntry}
        onRemoveEntry={removeMoodEntry}
      />
    );

    if (activeTab === 'kapasitas') return (
      <StudyCapacity 
        isDarkMode={isDarkMode} 
        tasks={tasks}
      />
    );
  };

  return (
    <div className={`flex h-screen overflow-hidden font-sans transition-all duration-500 relative ${isDarkMode ? 'bg-slate-950 text-white' : 'bg-gradient-to-br from-indigo-100/40 via-sky-50 to-pink-50/40 text-slate-900'}`}>
      {/* Aurora visual glowing mesh */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className={`absolute -top-40 -left-40 w-96 h-96 rounded-full blur-[110px] transition-all duration-1000 ${isDarkMode ? 'bg-indigo-900/15' : 'bg-indigo-450/20'}`} />
        <div className={`absolute top-1/3 -right-20 w-[500px] h-[500px] rounded-full blur-[130px] transition-all duration-1000 ${isDarkMode ? 'bg-blue-900/15' : 'bg-blue-250/20'}`} />
        <div className={`absolute -bottom-20 left-1/4 w-96 h-96 rounded-full blur-[100px] transition-all duration-1000 ${isDarkMode ? 'bg-violet-950/10' : 'bg-rose-300/20'}`} />
      </div>

      {/* Welcome Toast */}
      <AnimatePresence>
        {showWelcome && (
          <motion.div 
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 20, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            className="fixed top-0 left-1/2 -translate-x-1/2 z-[100] w-[90%] max-w-sm cursor-pointer"
            onClick={() => {
              speakGreeting();
              setShowWelcome(false);
            }}
          >
            <div className="bg-ocean text-white p-4 rounded-2xl shadow-2xl flex items-center gap-4 border-2 border-white/20 backdrop-blur-md hover:scale-105 transition-transform">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl shrink-0">
                👋
              </div>
              <div className="flex-1">
                <p className="text-[10px] text-white/70 uppercase tracking-wider">Ketuk untuk sapaan suara</p>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold">Halo, {userName}!</h3>
                  <Sparkles size={14} className="text-amber-300 animate-pulse" />
                </div>
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setShowWelcome(false);
                }} 
                className="p-1 hover:bg-white/10 rounded-lg"
              >
                <X size={18} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
 
      <Sidebar activeTab={activeTab} setActiveTab={handleTabChange} appName={appName} isDarkMode={isDarkMode} />
      
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden pb-20 md:pb-0 relative z-10">
        {/* Header */}
        <header className={`h-20 border-b flex items-center justify-between px-4 md:px-8 flex-shrink-0 transition-all duration-300 ${isDarkMode ? 'bg-slate-950/20 border-slate-800/80 backdrop-blur-md' : 'bg-white/30 border-slate-100/80 backdrop-blur-md'}`}>
          <div className="flex items-center gap-3">
            <div className="md:hidden w-8 h-8 bg-gradient-to-tr from-ocean to-indigo-600 rounded-lg flex items-center justify-center text-white text-xs shadow-lg shadow-ocean/20 animate-bounce">🎓</div>
            <div>
              <span className="text-slate-400 text-[10px] md:text-xs font-semibold uppercase tracking-widest hidden xs:block text-nowrap">Halo, {userName.trim() || 'Mahasiswa'}! 👋</span>
              <h2 className={`text-lg md:text-xl font-extrabold capitalize truncate bg-gradient-to-r ${isDarkMode ? 'from-cyan-300 via-blue-400 to-indigo-400' : 'from-blue-600 via-indigo-600 to-purple-600'} bg-clip-text text-transparent`}>
                {activeTab === 'settings' ? 'Pengaturan' : activeTab.replace('-', ' ')}
              </h2>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowNotifPanel(!showNotifPanel)}
              className={`relative w-10 h-10 flex items-center justify-center rounded-xl transition-all hover:scale-110 active:scale-95 ${isDarkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-50 text-slate-400'} ${showNotifPanel ? 'ring-2 ring-ocean text-ocean' : ''}`}
            >
              <Bell size={20} />
              {(notifications.length > 0 || schedule.length > 0) && (
                <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white animate-pulse" />
              )}
            </button>
            <div 
              className={`flex items-center gap-3 pl-4 border-l cursor-pointer ${isDarkMode ? 'border-slate-800' : 'border-slate-100'}`}
              onClick={() => handleTabChange('settings')}
            >
              <div className="text-right hidden sm:block">
                <p className={`text-sm font-bold truncate max-w-[120px] ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{userName.trim() || 'Mahasiswa'}</p>
                <div className="flex items-center gap-1 justify-end">
                  <Sparkles size={12} className="text-amber-400" />
                  <p className="text-[10px] font-bold text-amber-500 uppercase">Premium Member</p>
                </div>
              </div>
              <div className="w-10 h-10 rounded-xl bg-sky-light border-2 border-white shadow-sm overflow-hidden">
                {avatar ? (
                  <img src={avatar} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <img 
                    src="https://api.dicebear.com/7.x/avataaars/svg?seed=Saiful" 
                    alt="Default Avatar"
                    className="w-full h-full object-cover"
                  />
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div 
          ref={scrollContainerRef}
          className="flex-1 overflow-x-hidden overflow-y-auto p-4 md:p-8 flex flex-col scroll-smooth no-scrollbar"
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.3 }}
              className="flex-1 h-full"
            >
              {activeTab !== 'settings' && (
                <div className={`mb-6 p-4 rounded-2xl border flex items-center gap-3 ${isDarkMode ? 'bg-indigo-950/20 border-indigo-900/30' : 'bg-indigo-50 border-indigo-100'}`}>
                  <Sparkles className="text-indigo-500 shrink-0" size={20} />
                  <p className={`text-[10px] md:text-xs font-medium ${isDarkMode ? 'text-indigo-300' : 'text-indigo-700'}`}>
                    <b>Beta:</b> Aplikasi dalam tahap pengembangan. Kritik & saran sangat dihargai!
                  </p>
                </div>
              )}
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Notification Panel Overlay */}
      <AnimatePresence>
        {showNotifPanel && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowNotifPanel(false)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[150] md:hidden"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -20, x: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0, x: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20, x: 20 }}
              className={`fixed top-20 right-4 md:right-8 z-[160] w-[calc(100vw-32px)] md:w-96 rounded-3xl shadow-2xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}
            >
              <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-ocean/5">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-ocean text-white rounded-lg flex items-center justify-center">
                    <Bell size={16} />
                  </div>
                  <h3 className={`font-bold ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Pusat Notifikasi</h3>
                </div>
                <button 
                  onClick={() => setShowNotifPanel(false)}
                  className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                >
                  <X size={20} className="text-slate-400" />
                </button>
              </div>

              <div className="max-h-[70vh] overflow-y-auto p-4 space-y-6">
                {/* Deadlines Section */}
                {notifications.length > 0 && (
                  <div className="space-y-3">
                    <h4 className="text-[10px] uppercase tracking-widest font-bold text-rose-500 flex items-center gap-2">
                       <AlertTriangle size={12} /> Deadline Mendatang
                    </h4>
                    <div className="space-y-2">
                      {notifications.map(task => {
                        const deadlineDate = new Date(task.deadline);
                        const today = new Date('2026-05-09');
                        const diffTime = deadlineDate.getTime() - today.getTime();
                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                        
                        return (
                          <div 
                            key={task.id} 
                            onClick={() => { setActiveTab('tugas'); setShowNotifPanel(false); }}
                            className={`p-3 rounded-2xl border cursor-pointer hover:scale-[1.02] transition-transform ${isDarkMode ? 'bg-slate-800/50 border-rose-900/30' : 'bg-rose-50 border-rose-100'}`}
                          >
                            <div className="flex justify-between items-start">
                              <p className={`text-sm font-bold ${isDarkMode ? 'text-slate-200' : 'text-slate-700'}`}>{task.title}</p>
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-rose-200 text-rose-700">
                                H-{diffDays}
                              </span>
                            </div>
                            <p className="text-[10px] text-rose-500 mt-1">Selesaikan sebelum deadline!</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Today's Schedule Section */}
                <div className="space-y-3">
                  <h4 className={`text-[10px] uppercase tracking-widest font-bold flex items-center gap-2 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                    Jadwal Hari Ini
                  </h4>
                  <div className="space-y-2">
                    {(() => {
                      const daysIndo = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
                      const currentDayIndo = daysIndo[new Date().getDay()];
                      const todaysClass = schedule.filter(s => s.day === currentDayIndo);
                      return todaysClass.length > 0 ? (
                        todaysClass.map(item => (
                          <div key={item.id} className={`p-3 rounded-2xl border border-transparent ${isDarkMode ? 'bg-slate-800/30' : 'bg-slate-50'}`}>
                            <div className="flex items-center justify-between">
                              <p className={`text-sm font-semibold truncate ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{item.title}</p>
                              <span className="text-[10px] font-bold text-ocean">{item.startTime}</span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-slate-400 italic text-center py-2">
                          Tidak ada jadwal ({currentDayIndo}) hari ini
                        </p>
                      );
                    })()}
                  </div>
                </div>

                {/* Tip Section */}
                <div className={`p-4 rounded-2xl border border-dashed ${isDarkMode ? 'border-ocean/20 bg-ocean/5' : 'border-sky-200 bg-sky-50'}`}>
                  <p className={`text-xs italic text-center ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    "Fokus pada satu tugas dulu, {userName.trim() || 'Mahasiswa'}. Kamu pasti bisa menyelesaikannya!" ✨
                  </p>
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-b-3xl text-center">
                <button 
                  onClick={() => { setActiveTab('jadwal'); setShowNotifPanel(false); }}
                  className="text-xs font-bold text-ocean hover:underline"
                >
                  Lihat Semua Aktivitas
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Floating Action Button (Optional) */}
      <BottomNav activeTab={activeTab} setActiveTab={handleTabChange} isDarkMode={isDarkMode} />
    </div>
  );
}

