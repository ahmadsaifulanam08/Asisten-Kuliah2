/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export async function askTutor(message: string, history: { role: 'user' | 'model', content: string }[]) {
  try {
    const response = await fetch('/api/ai/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, history }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || 'Gagal menghubungi AI Tutor.');
    }

    const data = await response.json();
    return data.text;
  } catch (error) {
    console.error("AI Proxy Error:", error);
    throw new Error("Layanan AI sedang gangguan. Coba lagi nanti.");
  }
}

export async function summarizeHandwriting(imageBase64: string, mimeType: string = 'image/jpeg') {
  try {
    const response = await fetch('/api/ai/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image: imageBase64, mimeType }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || 'Gagal memindai gambar.');
    }

    const data = await response.json();
    return data.text;
  } catch (error: any) {
    console.error("AI Scan Proxy Error:", error);
    throw new Error(error.message || "Gagal menghubungkan ke layanan pemindaian.");
  }
}
