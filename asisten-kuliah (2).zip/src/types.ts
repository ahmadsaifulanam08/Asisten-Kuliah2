/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ScheduleItem {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  day: string; // "Monday", etc.
  type: 'class' | 'study' | 'break';
}

export interface Task {
  id: string;
  title: string;
  deadline: string;
  isCompleted: boolean;
  priority: 'low' | 'medium' | 'high';
}

export interface MoodEntry {
  id: string;
  date: string; // ISO format
  day: string; // e.g., "Senin"
  time: string; // e.g., "14:30"
  mood: 'great' | 'good' | 'neutral' | 'tired' | 'stressed';
  label: string; // The display name of the mood
  emoji: string;
  note?: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface ScheduleHistoryItem {
  id: string;
  timestamp: string; // ISO String
  actionType: 'add' | 'edit' | 'delete' | 'restore';
  description: string;
  oldSchedule?: ScheduleItem;
  newSchedule?: ScheduleItem;
}

