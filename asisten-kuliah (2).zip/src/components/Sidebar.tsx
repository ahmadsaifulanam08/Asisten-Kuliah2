/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Calendar, CheckSquare, ScanText, Heart, Settings, BarChart2 } from 'lucide-react';
import { motion } from 'motion/react';

interface NavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  appName: string;
  isDarkMode: boolean;
}

export default function Sidebar({ activeTab, setActiveTab, appName, isDarkMode }: NavProps) {
  const menuItems = [
    { id: 'jadwal', label: 'Jadwal', icon: Calendar },
    { id: 'tugas', label: 'Tugas', icon: CheckSquare },
    { id: 'scan', label: 'Scan', icon: ScanText },
    { id: 'mood', label: 'Mood', icon: Heart },
    { id: 'kapasitas', label: 'Kapasitas', icon: BarChart2 },
  ];

  return (
    <div className={`hidden md:flex w-20 md:w-64 h-full border-r flex-col p-4 transition-all duration-300 ${isDarkMode ? 'bg-slate-900/40 border-slate-800/80 backdrop-blur-md' : 'bg-white/40 border-slate-100/80 backdrop-blur-md'}`}>
      <div className="flex items-center gap-3 mb-10 px-2 cursor-pointer" onClick={() => setActiveTab('jadwal')}>
        <div className="w-10 h-10 bg-gradient-to-tr from-ocean to-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-ocean/30 hover:scale-105 transition-transform duration-300">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            🎓
          </motion.div>
        </div>
        <h1 className={`text-xl font-extrabold hidden md:block bg-gradient-to-r ${isDarkMode ? 'from-cyan-450 to-indigo-400' : 'from-ocean to-indigo-600'} bg-clip-text text-transparent`}>{appName}</h1>
      </div>

      <nav className="flex-1 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-300 relative ${
              activeTab === item.id 
                ? `${isDarkMode ? 'bg-indigo-500/15 text-cyan-300 font-semibold' : 'bg-gradient-to-r from-blue-50 to-indigo-50/50 text-indigo-700 font-semibold'}` 
                : `${isDarkMode ? 'text-slate-500 hover:text-white hover:bg-slate-800/50' : 'text-slate-500 hover:bg-slate-100/50 hover:text-ocean'}`
            }`}
          >
            <item.icon size={22} strokeWidth={activeTab === item.id ? 2.5 : 2} />
            <span className="font-semibold hidden md:block">{item.label}</span>
            {activeTab === item.id && (
              <motion.div
                layoutId="active-pill"
                className="absolute left-0 w-1.5 h-8 bg-gradient-to-b from-ocean to-indigo-600 rounded-r-full"
              />
            )}
          </button>
        ))}
      </nav>

      <div className={`pt-10 border-t ${isDarkMode ? 'border-slate-800' : 'border-slate-100'}`}>
        <button 
          onClick={() => setActiveTab('settings')}
          className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-300 ${
            activeTab === 'settings' 
              ? `${isDarkMode ? 'bg-indigo-500/15 text-cyan-300 font-semibold' : 'bg-gradient-to-r from-blue-50 to-indigo-50/50 text-indigo-700 font-semibold'}` 
              : `${isDarkMode ? 'text-slate-500 hover:text-white hover:bg-slate-800/50' : 'text-slate-500 hover:bg-slate-100/50 hover:text-ocean'}`
          }`}
        >
          <Settings size={22} />
          <span className="font-semibold hidden md:block">Pengaturan</span>
        </button>
      </div>
    </div>
  );
}
