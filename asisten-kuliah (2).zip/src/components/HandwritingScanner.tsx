/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Camera, Image as ImageIcon, Sparkles, Loader2, RefreshCw, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { summarizeHandwriting } from '../services/geminiService';

interface ScannerProps {
  isDarkMode: boolean;
}

export default function HandwritingScanner({ isDarkMode }: ScannerProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [summary, setSummary] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setErrorMsg(null);
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setSummary(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProcess = async () => {
    if (!selectedImage) return;
    setIsProcessing(true);
    setErrorMsg(null);
    try {
      const match = selectedImage.match(/^data:([^;]+);base64,/);
      const mimeType = match ? match[1] : 'image/jpeg';
      const base64Data = selectedImage.split(',')[1];
      const result = await summarizeHandwriting(base64Data, mimeType);
      setSummary(result || '');
    } catch (error) {
      console.error(error);
      setErrorMsg('Maaf, terjadi kesalahan saat memproses gambar oleh AI. Pastikan file gambar Anda di bawah 5MB dan coba lagi.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto pb-10">
      <div className={`p-6 md:p-8 rounded-3xl shadow-sm border transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-xl shadow-indigo-100/10'}`}>
        <div className="text-center mb-8 md:mb-10">
          <div className={`w-14 h-14 md:w-16 md:h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 transition-colors ${isDarkMode ? 'bg-slate-700 text-ocean' : 'bg-sky-light text-ocean'}`}>
            <Camera size={28} />
          </div>
          <h2 className={`text-xl md:text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Scan Catatan Kuliah</h2>
          <p className="text-slate-500 mt-2 text-sm md:text-lg">Foto catatanmu dan biarkan AI merangkumnya otomatis!</p>
        </div>

        {!selectedImage ? (
          <label className={`flex flex-col items-center justify-center w-full h-64 md:h-80 border-3 border-dashed rounded-3xl transition-all cursor-pointer group ${isDarkMode ? 'border-slate-700 hover:border-ocean hover:bg-slate-700' : 'border-slate-200 hover:border-ocean hover:bg-sky-50'}`}>
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <ImageIcon size={48} className="text-slate-300 group-hover:text-ocean transition-colors mb-4" />
              <p className={`text-lg font-semibold group-hover:text-ocean px-4 text-center ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>Upload atau Foto Catatan</p>
              <p className="text-slate-400 mt-2 text-sm">Format JPG, PNG (Max 5MB)</p>
            </div>
            <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
          </label>
        ) : (
          <div className="space-y-6">
            <div className={`relative rounded-3xl overflow-hidden border-4 shadow-inner group ${isDarkMode ? 'border-slate-700' : 'border-slate-100'}`}>
              <img src={selectedImage} alt="Selected" className="w-full h-auto max-h-80 md:max-h-96 object-contain bg-slate-50" />
              <button 
                onClick={() => { setSelectedImage(null); setSummary(null); }}
                className={`absolute top-4 right-4 backdrop-blur p-2 md:p-3 rounded-2xl hover:bg-white transition-all shadow-lg ${isDarkMode ? 'bg-slate-800/80 text-slate-300' : 'bg-white/90 text-slate-600'}`}
              >
                <RefreshCw size={20} />
              </button>
            </div>

            {errorMsg && (
              <div className="flex gap-3 items-center p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-rose-500 text-sm font-semibold animate-pulse">
                <AlertCircle className="shrink-0" size={20} />
                <p>{errorMsg}</p>
              </div>
            )}

            {!summary && (
              <button
                onClick={handleProcess}
                disabled={isProcessing}
                className="w-full bg-ocean text-white py-4 md:py-5 rounded-2xl font-bold text-lg md:text-xl shadow-lg shadow-ocean/30 hover:bg-ocean/90 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="animate-spin" size={24} />
                    Menganalisis...
                  </>
                ) : (
                  <>
                    <Sparkles size={24} />
                    Rangkum Sekarang
                  </>
                )}
              </button>
            )}
          </div>
        )}
      </div>

      <AnimatePresence>
        {summary && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-6 md:p-10 rounded-3xl shadow-sm border transition-all prose prose-slate max-w-none prose-headings:text-ocean prose-strong:text-ocean ${isDarkMode ? 'bg-slate-900/60 border-slate-800/80 backdrop-blur-md prose-invert prose-p:text-slate-305 prose-li:text-slate-305' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-xl shadow-indigo-100/10 prose-p:text-slate-750 prose-li:text-slate-750'}`}
          >
            <div className={`flex items-center justify-between mb-8 pb-4 border-b ${isDarkMode ? 'border-slate-700' : 'border-slate-100'}`}>
              <div className="flex items-center gap-3">
                <Sparkles className="text-ocean w-6 h-6 md:w-7 md:h-7" />
                 <h3 className={`m-0 text-xl md:text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Hasil Rangkuman AI</h3>
              </div>
              <button 
                onClick={() => { setSelectedImage(null); setSummary(null); setErrorMsg(null); }}
                className="text-ocean font-bold hover:underline py-2 px-4 rounded-xl hover:bg-sky-50 transition-colors text-sm md:text-base"
                id="reset-scan"
              >
                Scan Lagi
              </button>
            </div>
            <div className="markdown-body leading-relaxed text-base md:text-lg">
              <Markdown>{summary}</Markdown>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
