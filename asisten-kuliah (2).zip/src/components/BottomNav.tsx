import React from 'react';
import { Calendar, CheckSquare, ScanText, Heart, Settings, BarChart2 } from 'lucide-react';
import { motion } from 'motion/react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isDarkMode: boolean;
}

export default function BottomNav({ activeTab, setActiveTab, isDarkMode }: BottomNavProps) {
  const menuItems = [
    { id: 'jadwal', icon: Calendar, label: 'Jadwal' },
    { id: 'tugas', icon: CheckSquare, label: 'Tugas' },
    { id: 'scan', icon: ScanText, label: 'Scan' },
    { id: 'mood', icon: Heart, label: 'Mood' },
    { id: 'kapasitas', icon: BarChart2, label: 'Kapasitas' },
    { id: 'settings', icon: Settings, label: 'Menu' },
  ];

  return (
    <div className={`fixed bottom-0 left-0 right-0 z-[100] md:hidden border-t border-slate-150/30 safe-area-inset-bottom ${isDarkMode ? 'bg-slate-950/80' : 'bg-white/60'} backdrop-blur-2xl shadow-xl transition-colors duration-300`}>
      <div className="flex items-center justify-around p-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center gap-1 p-1.5 rounded-2xl transition-all duration-300 ${
              activeTab === item.id 
                ? `${isDarkMode ? 'text-cyan-400 scale-105' : 'text-indigo-600 scale-105 font-bold'}` 
                : isDarkMode ? 'text-slate-500 hover:text-text-white' : 'text-slate-450 hover:text-indigo-500'
            }`}
          >
            <div className="relative">
              <item.icon size={20} strokeWidth={activeTab === item.id ? 2.5 : 2} />
              {activeTab === item.id && (
                <motion.div
                  layoutId="bottom-nav-indicator"
                  className={`absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full ${isDarkMode ? 'bg-cyan-400' : 'bg-indigo-600'}`}
                />
              )}
            </div>
            <span className="text-[8px] xs:text-[9px] font-bold uppercase tracking-tighter truncate max-w-[56px] text-center">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
