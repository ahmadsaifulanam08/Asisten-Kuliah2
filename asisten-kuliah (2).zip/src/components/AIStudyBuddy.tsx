/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, Volume2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { askTutor } from '../services/geminiService';
import { ChatMessage } from '../types';

interface AIBuddyProps {
  aiName: string;
  isDarkMode: boolean;
}

export default function AIStudyBuddy({ aiName, isDarkMode }: AIBuddyProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', content: `Halo! Aku ${aiName}, teman belajarmu. Ada materi yang bikin pusing atau butuh bantuan tugas? Tanya aja!` }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  const speak = (text: string) => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel(); // Stop any current speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'id-ID';
      window.speechSynthesis.speak(utterance);
    }
  };

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await askTutor(input, messages);
      const botMsg: ChatMessage = { role: 'model', content: response || 'Maaf, aku lagi bingung. Bisa tanya lagi?' };
      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Oops, terjadi kesalahan koneksi. Coba lagi ya!';
      setMessages(prev => [...prev, { role: 'model', content: errorMsg }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`flex flex-col flex-1 min-h-[400px] h-full rounded-3xl shadow-sm border overflow-hidden transition-colors ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-50'}`}>
      <div className="p-4 bg-ocean text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <Bot size={22} />
          </div>
          <div>
            <h2 className="font-bold">{aiName}</h2>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <p className="text-xs text-white/70">Online & Siap Membantu</p>
            </div>
          </div>
        </div>
        <Sparkles size={20} className="text-white/50" />
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`flex gap-2 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${
                msg.role === 'user' ? 'bg-sky-light text-ocean' : `${isDarkMode ? 'bg-slate-800 text-slate-500' : 'bg-slate-100 text-slate-500'}`
              }`}>
                {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={`p-4 rounded-2xl relative group ${
                msg.role === 'user' 
                  ? 'bg-ocean text-white rounded-tr-none' 
                  : `${isDarkMode ? 'bg-slate-800 text-slate-200 border-slate-700' : 'bg-slate-50 text-slate-800 border-slate-100'} rounded-tl-none border`
              }`}>
                <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                {msg.role === 'model' && (
                  <button 
                    onClick={() => speak(msg.content)}
                    className="absolute -right-10 top-0 p-2 text-slate-300 hover:text-ocean transition-colors opacity-0 group-hover:opacity-100"
                    title="Dengarkan Jawaban"
                  >
                    <Volume2 size={18} />
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className={`flex gap-2 items-center p-4 rounded-2xl rounded-tl-none border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
              <div className="flex gap-1">
                <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6 }} className="w-2 h-2 bg-slate-300 rounded-full" />
                <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }} className="w-2 h-2 bg-slate-300 rounded-full" />
                <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }} className="w-2 h-2 bg-slate-300 rounded-full" />
              </div>
            </div>
          </div>
        )}
        <div ref={endOfMessagesRef} />
      </div>

      <div className={`p-4 border-t transition-colors ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
        <div className={`flex gap-2 p-1.5 rounded-2xl border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Tulis pertanyaanmu di sini..."
            className={`flex-1 bg-transparent px-4 py-2 focus:outline-none ${isDarkMode ? 'text-white' : 'text-slate-800'}`}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all ${
              input.trim() && !isLoading ? 'bg-ocean text-white shadow-lg shadow-ocean/30' : 'bg-slate-200 text-slate-400'
            }`}
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
