/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, CheckCircle2, Circle, Clock, Plus, Trash2, 
  AlertCircle, Edit2, History, List, CalendarDays, RotateCcw, Check, X, ShieldAlert, BadgeInfo, ChevronDown,
  BookOpen, Coffee, Flame, TrendingUp, BarChart2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Task, ScheduleItem, ScheduleHistoryItem } from '../types';

interface DashboardProps {
  tasks: Task[];
  toggleTask: (id: string) => void;
  removeTask: (id: string) => void;
  addTask: (task: Omit<Task, 'id' | 'isCompleted'>) => void;
  schedule: ScheduleItem[];
  addSchedule: (item: Omit<ScheduleItem, 'id'>) => void;
  removeSchedule: (id: string) => void;
  updateSchedule?: (item: ScheduleItem) => void;
  scheduleHistory?: ScheduleHistoryItem[];
  restoreScheduleHistory?: (item: ScheduleHistoryItem) => void;
  clearScheduleHistory?: () => void;
  isDarkMode: boolean;
  showOnly?: 'jadwal' | 'tugas';
}

const DAYS_INDONESIAN = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];

export default function Dashboard({ 
  tasks, toggleTask, removeTask, addTask, 
  schedule, addSchedule, removeSchedule, 
  updateSchedule, scheduleHistory = [], restoreScheduleHistory, clearScheduleHistory,
  isDarkMode, showOnly
}: DashboardProps) {
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [scheduleViewMode, setScheduleViewMode] = useState<'calendar' | 'list' | 'history'>('calendar');
  
  // State for task input
  const [newTask, setNewTask] = useState({
    title: '',
    deadline: '',
    priority: 'medium' as 'low' | 'medium' | 'high'
  });

  // State for schedule form input (handles both add & edit)
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [scheduleFormData, setScheduleFormData] = useState({
    title: '',
    startTime: '',
    endTime: '',
    day: 'Senin',
    type: 'class' as 'class' | 'study' | 'break'
  });

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.title || !newTask.deadline) return;
    addTask(newTask);
    setNewTask({ title: '', deadline: '', priority: 'medium' });
    setShowTaskForm(false);
  };

  const handleScheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scheduleFormData.title || !scheduleFormData.startTime || !scheduleFormData.endTime) return;

    if (editingItemId && updateSchedule) {
      // Editing Mode
      updateSchedule({
        id: editingItemId,
        ...scheduleFormData
      });
      setEditingItemId(null);
    } else {
      // Add Mode
      addSchedule(scheduleFormData);
    }

    setScheduleFormData({
      title: '',
      startTime: '',
      endTime: '',
      day: 'Senin',
      type: 'class'
    });
    setShowScheduleForm(false);
  };

  // Open the schedule form in Editing Mode
  const startEditSchedule = (item: ScheduleItem) => {
    setEditingItemId(item.id);
    setScheduleFormData({
      title: item.title,
      startTime: item.startTime,
      endTime: item.endTime,
      day: item.day,
      type: item.type
    });
    setShowScheduleForm(true);
  };

  // Open form with a pre-selected day from the calendar
  const startAddScheduleWithDay = (day: string) => {
    setEditingItemId(null);
    setScheduleFormData({
      title: '',
      startTime: '',
      endTime: '',
      day: day,
      type: 'class'
    });
    setShowScheduleForm(true);
  };

  const getPriorityColor = (p: string) => {
    switch (p) {
      case 'high': return 'text-rose-500 bg-rose-50 border-rose-100 dark:bg-rose-950/20 dark:border-rose-900/30';
      case 'medium': return 'text-amber-500 bg-amber-50 border-amber-100 dark:bg-amber-950/20 dark:border-amber-900/30';
      default: return 'text-ocean bg-ocean/5 border-ocean/10 dark:bg-ocean/10 dark:border-ocean/20';
    }
  };

  const getScheduleColor = (type: string) => {
    switch (type) {
      case 'class': 
        return isDarkMode 
          ? 'bg-blue-900/25 border-blue-900/30 text-blue-200 hover:bg-blue-900/40' 
          : 'bg-blue-50 border-blue-100 text-blue-700 hover:bg-blue-100/60';
      case 'study': 
        return isDarkMode 
          ? 'bg-emerald-900/25 border-emerald-900/30 text-emerald-200 hover:bg-emerald-900/40' 
          : 'bg-emerald-50 border-emerald-100 text-emerald-700 hover:bg-emerald-100/60';
      case 'break': 
        return isDarkMode 
          ? 'bg-amber-900/25 border-amber-900/30 text-amber-200 hover:bg-amber-900/40' 
          : 'bg-amber-50 border-amber-100 text-amber-700 hover:bg-amber-100/60';
      default: 
        return isDarkMode 
          ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700' 
          : 'bg-white border-slate-100 text-slate-700 hover:bg-slate-50';
    }
  };

  const getSchedulePillTypeColor = (type: string) => {
    switch (type) {
      case 'class': return 'bg-blue-500 text-white';
      case 'study': return 'bg-emerald-500 text-white';
      case 'break': return 'bg-amber-500 text-white';
      default: return 'bg-slate-500 text-white';
    }
  };

  // Sort schedule items by start time
  const sortScheduleItems = (items: ScheduleItem[]) => {
    return [...items].sort((a, b) => a.startTime.localeCompare(b.startTime));
  };

  // Calculate statistics for schedule items
  const getDurationMinutes = (start: string, end: string) => {
    if (!start || !end) return 0;
    try {
      const [startH, startM] = start.split(':').map(Number);
      const [endH, endM] = end.split(':').map(Number);
      if (isNaN(startH) || isNaN(startM) || isNaN(endH) || isNaN(endM)) return 0;
      const startTotal = startH * 60 + startM;
      const endTotal = endH * 60 + endM;
      return Math.max(0, endTotal - startTotal);
    } catch {
      return 0;
    }
  };

  const scheduleStats = schedule.reduce(
    (acc, item) => {
      const mins = getDurationMinutes(item.startTime, item.endTime);
      if (item.type === 'class') {
        acc.classMinutes += mins;
        acc.classCount += 1;
      } else if (item.type === 'study') {
        acc.studyMinutes += mins;
        acc.studyCount += 1;
      } else if (item.type === 'break') {
        acc.breakMinutes += mins;
        acc.breakCount += 1;
      }
      acc.totalMinutes += mins;
      return acc;
    },
    { classMinutes: 0, studyMinutes: 0, breakMinutes: 0, totalMinutes: 0, classCount: 0, studyCount: 0, breakCount: 0 }
  );

  const classHoursVal = scheduleStats.classMinutes / 60;
  const studyHoursVal = scheduleStats.studyMinutes / 60;
  const breakHoursVal = scheduleStats.breakMinutes / 60;

  const classHoursStr = (scheduleStats.classMinutes / 60).toFixed(classHoursVal % 1 === 0 ? 0 : 1);
  const studyHoursStr = (scheduleStats.studyMinutes / 60).toFixed(studyHoursVal % 1 === 0 ? 0 : 1);
  const breakHoursStr = (scheduleStats.breakMinutes / 60).toFixed(breakHoursVal % 1 === 0 ? 0 : 1);
  const totalHoursStr = (scheduleStats.totalMinutes / 60).toFixed((scheduleStats.totalMinutes / 60) % 1 === 0 ? 0 : 1);

  // Density Level calculation (Kepadatan Jadwal)
  let densityLabel = 'Sempurna';
  let densityTone = 'emerald'; 
  let densityAdvice = 'Porsi belajar mandiri, perkuliahan, dan rehat Anda seimbang dengan sangat baik!';

  if (classHoursVal === 0) {
    densityLabel = 'Kosong';
    densityTone = 'slate';
    densityAdvice = 'Belum ada jadwal kuliah yang ditambahkan. Silakan tambahkan jam kuliah Anda.';
  } else if (classHoursVal < 12) {
    densityLabel = 'Senggang';
    densityTone = 'sky';
    densityAdvice = 'Jadwal kuliah cukup luang. Sempurna untuk eksplorasi diri atau hobi akademis!';
  } else if (classHoursVal >= 12 && classHoursVal <= 24) {
    densityLabel = 'Optimal';
    densityTone = 'emerald';
    densityAdvice = 'Kepadatan jadwal kuliah Anda optimal! Keseimbangan antara studi dan energi terjaga.';
  } else if (classHoursVal > 24 && classHoursVal <= 36) {
    densityLabel = 'Padat';
    densityTone = 'amber';
    densityAdvice = 'Jadwal mulai memadat. Usahakan untuk menjaga pola makan dan istirahat berkualitas.';
  } else {
    densityLabel = 'Sangat Padat (Overload)';
    densityTone = 'rose';
    densityAdvice = 'Peringatan burnout! Mohon kurangi aktivitas kuliah/belajar non-esensial demi kesehatan.';
  }

  return (
    <div className={showOnly ? "space-y-6" : "grid grid-cols-1 lg:grid-cols-2 gap-8 h-full overflow-y-auto pr-2 pb-10"}>
      {/* Schedule Management Section */}
      {(!showOnly || showOnly === 'jadwal') && (
        <div className="space-y-6">
          
          {/* Header Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2 md:gap-3">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${isDarkMode ? 'bg-slate-850 text-ocean' : 'bg-sky-light text-ocean'}`}>
                <CalendarIcon size={22} className="text-ocean" />
              </div>
              <div>
                <h2 className={`text-xl md:text-2xl font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Jadwal Kuliah</h2>
                <p className="text-xs text-slate-400 mt-0.5">Kelola aktivitas mingguan & arsip histori Anda.</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              {/* Add New Schedule Shortcut */}
              <button 
                onClick={() => {
                  setEditingItemId(null);
                  setScheduleFormData({ title: '', startTime: '', endTime: '', day: 'Senin', type: 'class' });
                  setShowScheduleForm(true);
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-ocean text-white rounded-xl text-xs md:text-sm font-bold shadow-lg shadow-ocean/20 hover:scale-[1.03] active:scale-95 transition-all outline-none"
              >
                <Plus size={16} />
                Tambah Jadwal
              </button>
            </div>
          </div>

          {/* Schedule Statistics & Density Predictor Panel */}
          <div className={`p-5 rounded-3xl border transition-all ${isDarkMode ? 'bg-slate-900/40 border-slate-800 backdrop-blur-md' : 'bg-white/60 border-white/80 backdrop-blur-md shadow-xl shadow-indigo-100/20'}`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                <BarChart2 size={14} className="text-ocean" />
                Statistik Mingguan & Kepadatan
              </h3>
              {classHoursVal > 0 && (
                <span className={`text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full border flex items-center gap-1.5 ${
                  densityTone === 'slate' ? (isDarkMode ? 'bg-slate-950 text-slate-400 border-slate-800' : 'bg-slate-100/80 text-slate-600 border-slate-200') :
                  densityTone === 'sky' ? (isDarkMode ? 'bg-sky-950/40 text-sky-300 border-sky-900/30' : 'bg-sky-50/80 text-sky-700 border-sky-100') :
                  densityTone === 'emerald' ? (isDarkMode ? 'bg-emerald-950/40 text-emerald-300 border-emerald-900/30' : 'bg-emerald-50/80 text-emerald-700 border-emerald-100') :
                  densityTone === 'amber' ? (isDarkMode ? 'bg-amber-950/40 text-amber-300 border-amber-900/30' : 'bg-amber-50/80 text-amber-700 border-amber-100') :
                  (isDarkMode ? 'bg-rose-950/40 text-rose-300 border-rose-900/30' : 'bg-rose-50/80 text-rose-700 border-rose-100')
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full inline-block ${
                    densityTone === 'slate' ? 'bg-slate-400' :
                    densityTone === 'sky' ? 'bg-sky-500' :
                    densityTone === 'emerald' ? 'bg-emerald-500' :
                    densityTone === 'amber' ? 'bg-amber-500' : 'bg-rose-500'
                  } animate-pulse`} />
                  Kepadatan: {densityLabel}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              {/* Card 1: Total Jam Kuliah */}
              <div className={`p-3.5 rounded-2xl border transition-all flex items-center gap-3 ${
                isDarkMode ? 'bg-slate-850/50 border-slate-800 shadow-inner' : 'bg-white/80 border-slate-100/80 shadow-xs hover:shadow-md hover:scale-[1.01]'
              }`}>
                <div className={`p-2.5 rounded-xl flex-shrink-0 ${isDarkMode ? 'bg-blue-950/40 text-blue-400' : 'bg-blue-50 text-blue-600'}`}>
                  <BookOpen size={16} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Jam Kuliah</p>
                  <p className={`text-base font-bold leading-tight ${isDarkMode ? 'text-white' : 'text-slate-805'}`}>
                    {classHoursStr} <span className="text-xs font-normal text-slate-450">Jam / mgg</span>
                  </p>
                  <p className="text-[9px] text-slate-400 truncate">{scheduleStats.classCount} mata kuliah</p>
                </div>
              </div>

              {/* Card 2: Belajar Mandiri */}
              <div className={`p-3.5 rounded-2xl border transition-all flex items-center gap-3 ${
                isDarkMode ? 'bg-slate-850/50 border-slate-800 shadow-inner' : 'bg-white/80 border-slate-100/80 shadow-xs hover:shadow-md hover:scale-[1.01]'
              }`}>
                <div className={`p-2.5 rounded-xl flex-shrink-0 ${isDarkMode ? 'bg-emerald-950/40 text-emerald-400' : 'bg-emerald-50 text-emerald-600'}`}>
                  <Flame size={16} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Studi Mandiri</p>
                  <p className={`text-base font-bold leading-tight ${isDarkMode ? 'text-white' : 'text-slate-805'}`}>
                    {studyHoursStr} <span className="text-xs font-normal text-slate-455">Jam / mgg</span>
                  </p>
                  <p className="text-[9px] text-slate-400 truncate">{scheduleStats.studyCount} sesi belajar</p>
                </div>
              </div>

              {/* Card 3: Rehat & Istirahat */}
              <div className={`p-3.5 rounded-2xl border transition-all flex items-center gap-3 ${
                isDarkMode ? 'bg-slate-850/50 border-slate-800 shadow-inner' : 'bg-white/80 border-slate-100/80 shadow-xs hover:shadow-md hover:scale-[1.01]'
              }`}>
                <div className={`p-2.5 rounded-xl flex-shrink-0 ${isDarkMode ? 'bg-amber-950/40 text-amber-400' : 'bg-amber-50 text-amber-600'}`}>
                  <Coffee size={16} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Rehat Mingguan</p>
                  <p className={`text-base font-bold leading-tight ${isDarkMode ? 'text-white' : 'text-slate-805'}`}>
                    {breakHoursStr} <span className="text-xs font-normal text-slate-455">Jam / mgg</span>
                  </p>
                  <p className="text-[9px] text-slate-400 truncate">{scheduleStats.breakCount} kali istirahat</p>
                </div>
              </div>
            </div>

            {/* Distribution Visual Range Slider Bar */}
            {scheduleStats.totalMinutes > 0 ? (
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold px-0.5">
                  <span className="uppercase tracking-wider">Proporsi Jam Kegiatan</span>
                  <span className={isDarkMode ? 'text-slate-300' : 'text-slate-600'}>Jumlah Sesi: {schedule.length} • Total: {totalHoursStr} Jam</span>
                </div>
                <div className="w-full h-2.5 rounded-full overflow-hidden flex bg-slate-205 dark:bg-slate-800">
                  {scheduleStats.classMinutes > 0 && (
                    <div 
                      className="h-full bg-blue-500 transition-all duration-500" 
                      style={{ width: `${(scheduleStats.classMinutes / scheduleStats.totalMinutes) * 100}%` }}
                      title={`Kuliah: ${((scheduleStats.classMinutes / scheduleStats.totalMinutes) * 100).toFixed(0)}%`}
                    />
                  )}
                  {scheduleStats.studyMinutes > 0 && (
                    <div 
                      className="h-full bg-emerald-500 transition-all duration-500" 
                      style={{ width: `${(scheduleStats.studyMinutes / scheduleStats.totalMinutes) * 100}%` }}
                      title={`Belajar: ${((scheduleStats.studyMinutes / scheduleStats.totalMinutes) * 100).toFixed(0)}%`}
                    />
                  )}
                  {scheduleStats.breakMinutes > 0 && (
                    <div 
                      className="h-full bg-amber-500 transition-all duration-500" 
                      style={{ width: `${(scheduleStats.breakMinutes / scheduleStats.totalMinutes) * 100}%` }}
                      title={`Rehat: ${((scheduleStats.breakMinutes / scheduleStats.totalMinutes) * 100).toFixed(0)}%`}
                    />
                  )}
                </div>
                <div className="p-3.5 rounded-2xl flex items-start gap-2.5 bg-ocean/5 border border-ocean/10">
                  <span className="text-sm">💡</span>
                  <p className={`text-xs leading-relaxed ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                    <span className="font-bold text-ocean">Analisis Beban:</span> {densityAdvice}
                  </p>
                </div>
              </div>
            ) : (
              <div className="mt-3 p-3.5 text-center text-xs text-slate-400 border border-dashed rounded-2xl dark:border-slate-800">
                Belum ada agenda jam kuliah, studi mandiri, atau rehat. Persentase proporsi kegiatan Anda akan tampil di sini.
              </div>
            )}
          </div>

          {/* Tab Selection Switches: Calendar View, Unified Timeline list, Changes logs */}
          <div className={`flex p-1 rounded-2xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white/40 border-slate-100/80 backdrop-blur-md shadow-inner'}`}>
            <button
              onClick={() => setScheduleViewMode('calendar')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                scheduleViewMode === 'calendar'
                  ? (isDarkMode ? 'bg-slate-800 text-white shadow' : 'bg-white text-ocean shadow-sm')
                  : 'text-slate-400 hover:text-slate-500'
              }`}
            >
              <CalendarDays size={14} />
              Kalender Mingguan
            </button>
            <button
              onClick={() => setScheduleViewMode('list')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                scheduleViewMode === 'list'
                  ? (isDarkMode ? 'bg-slate-800 text-white shadow' : 'bg-white text-ocean shadow-sm')
                  : 'text-slate-400 hover:text-slate-500'
              }`}
            >
              <List size={14} />
              Daftar Agenda
            </button>
            <button
              onClick={() => setScheduleViewMode('history')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all relative ${
                scheduleViewMode === 'history'
                  ? (isDarkMode ? 'bg-slate-800 text-white shadow' : 'bg-white text-ocean shadow-sm')
                  : 'text-slate-400 hover:text-slate-500'
              }`}
            >
              <History size={14} />
              Histori Perubahan
              {scheduleHistory.length > 0 && (
                <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              )}
            </button>
          </div>

          {/* Form Modal/Collapsible (handles addition & edit) */}
          <AnimatePresence>
            {showScheduleForm && (
              <div className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 15 }}
                  className={`w-full max-w-lg p-6 rounded-3xl border shadow-2xl relative overflow-hidden ${
                    isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-sky-100 shadow-sky-100/30'
                  }`}
                >
                  {/* Visual Accent Top Bar */}
                  <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-ocean to-cyan-400" />

                  <div className="flex items-center justify-between mb-5">
                    <h3 className={`font-bold flex items-center gap-2 text-sm md:text-base ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>
                      <CalendarIcon size={18} className="text-ocean" />
                      {editingItemId ? 'Ubah Informasi Kelas / Kegiatan' : 'Buat Sesi Jadwal Baru'}
                    </h3>
                    <button 
                      type="button" 
                      onClick={() => {
                        setShowScheduleForm(false);
                        setEditingItemId(null);
                      }}
                      className={`p-1.5 rounded-lg border ${isDarkMode ? 'border-slate-800 hover:bg-slate-800 text-slate-400' : 'border-slate-100 hover:bg-slate-50 text-slate-400'}`}
                    >
                      <X size={14} />
                    </button>
                  </div>

                  <form onSubmit={handleScheduleSubmit} className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Nama Mata Kuliah atau Kegiatan</label>
                      <input
                        type="text"
                        placeholder="Contoh: Pemrograman Web, Matematika Teknik, Jam Istirahat..."
                        className={`w-full px-4 py-3 rounded-2xl border font-medium focus:outline-none focus:ring-2 focus:ring-ocean transition-all text-sm ${
                          isDarkMode ? 'bg-slate-800 border-slate-700 text-white placeholder:text-slate-500' : 'bg-slate-50 border-slate-200 text-slate-800'
                        }`}
                        value={scheduleFormData.title}
                        onChange={e => setScheduleFormData({...scheduleFormData, title: e.target.value})}
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Waktu Mulai</label>
                        <input
                          type="time"
                          className={`w-full px-4 py-3 rounded-2xl border focus:outline-none focus:ring-2 focus:ring-ocean font-semibold text-sm ${
                            isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-850'
                          }`}
                          value={scheduleFormData.startTime}
                          onChange={e => setScheduleFormData({...scheduleFormData, startTime: e.target.value})}
                          required
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Waktu Selesai</label>
                        <input
                          type="time"
                          className={`w-full px-4 py-3 rounded-2xl border focus:outline-none focus:ring-2 focus:ring-ocean font-semibold text-sm ${
                            isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-850'
                          }`}
                          value={scheduleFormData.endTime}
                          onChange={e => setScheduleFormData({...scheduleFormData, endTime: e.target.value})}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Pilih Hari</label>
                        <div className="relative">
                          <select
                            className={`w-full pl-4 pr-10 py-3 rounded-2xl border focus:outline-none focus:ring-2 focus:ring-ocean font-semibold text-sm cursor-pointer appearance-none ${
                              isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'
                            }`}
                            value={scheduleFormData.day}
                            onChange={e => setScheduleFormData({...scheduleFormData, day: e.target.value})}
                          >
                            {DAYS_INDONESIAN.map(day => (
                              <option key={day} value={day}>{day}</option>
                            ))}
                          </select>
                          <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Kategori Aktivitas</label>
                        <div className="relative">
                          <select
                            className={`w-full pl-4 pr-10 py-3 rounded-2xl border focus:outline-none focus:ring-2 focus:ring-ocean font-semibold text-sm cursor-pointer appearance-none ${
                              isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-850'
                            }`}
                            value={scheduleFormData.type}
                            onChange={e => setScheduleFormData({...scheduleFormData, type: e.target.value as any})}
                          >
                            <option value="class">🎓 Kuliah Tatap Muka</option>
                            <option value="study">📖 Belajar Mandiri</option>
                            <option value="break">☕ Rehat & Istirahat</option>
                          </select>
                          <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <button 
                        type="submit"
                        className="flex-1 bg-ocean text-white py-3 rounded-2xl font-bold shadow-lg shadow-ocean/20 hover:opacity-95 transition-all text-sm outline-none"
                      >
                        {editingItemId ? 'Simpan Perubahan' : 'Tambahkan Sesi'}
                      </button>
                      <button 
                        type="button"
                        onClick={() => {
                          setShowScheduleForm(false);
                          setEditingItemId(null);
                        }}
                        className={`px-6 py-3 rounded-2xl font-bold transition-all text-sm ${
                          isDarkMode ? 'bg-slate-800 text-slate-400 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200/50 text-slate-500'
                        }`}
                      >
                        Batal
                      </button>
                    </div>
                  </form>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* TAB 1: CALENDAR VIEW FROM MONDAY TO SUNDAY */}
          {scheduleViewMode === 'calendar' && (
            <div className="space-y-4">
              {/* Alert prompt on how to use calendar */}
              <div className={`p-4 rounded-2xl border flex items-start gap-3 ${
                isDarkMode ? 'bg-slate-900/60 border-slate-820' : 'bg-sky-50/50 border-sky-100'
              }`}>
                <BadgeInfo size={18} className="text-ocean shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed text-slate-450">
                  Berikut kalender terstruktur <b>Senin s/d Minggu</b>. Anda dapat klik tombol <b>(+)</b> di pojok hari untuk menambahkan aktivitas baru langsung pada hari terkait. Klik ikon <b>Ubah/Edit</b> untuk menyunting jadwal.
                </p>
              </div>

              {/* 7-Day Grid Calendar View */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-7 gap-4">
                {DAYS_INDONESIAN.map((dayName) => {
                  const dayItems = sortScheduleItems(schedule.filter(s => s.day === dayName));
                  const totalMinutes = dayItems.reduce((acc, s) => {
                    const [sh, sm] = s.startTime.split(':').map(Number);
                    const [eh, em] = s.endTime.split(':').map(Number);
                    const durationDiff = (eh * 60 + em) - (sh * 60 + sm);
                    return acc + (durationDiff > 0 ? durationDiff : 0);
                  }, 0);
                  const totalHours = (totalMinutes / 60).toFixed(1);

                  return (
                    <div 
                      key={dayName}
                      className={`rounded-2xl border flex flex-col p-3 transition-all duration-300 ${
                        isDarkMode 
                        ? 'bg-slate-900/30 border-slate-800/80 hover:border-slate-705' 
                        : 'bg-white/60 border-white/60 backdrop-blur-md shadow-sm shadow-indigo-100/10 hover:shadow-lg hover:scale-[1.01]'
                      }`}
                    >
                      {/* Day card header with sum and helper add shortcut */}
                      <div className="flex items-center justify-between pb-2 mb-2 border-b border-dashed border-slate-200 dark:border-slate-800">
                        <div>
                          <span className={`text-sm font-bold block ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>
                            {dayName}
                          </span>
                          {dayItems.length > 0 && (
                            <span className="text-[9px] text-slate-400 font-semibold block uppercase">
                              {dayItems.length} Sesi ({totalHours}j)
                            </span>
                          )}
                        </div>
                        {/* Quick create item on day selected button */}
                        <button
                          onClick={() => startAddScheduleWithDay(dayName)}
                          className={`p-1 rounded-lg transition-transform active:scale-90 ${
                            isDarkMode ? 'bg-slate-800 text-slate-440 hover:text-white' : 'bg-slate-50 text-slate-400 hover:text-ocean'
                          }`}
                          title={`Tambah jadwal di hari ${dayName}`}
                        >
                          <Plus size={14} />
                        </button>
                      </div>

                      {/* Day list container */}
                      <div className="flex-1 space-y-2 min-h-[85px] flex flex-col justify-start">
                        {dayItems.length === 0 ? (
                          <div className={`flex-1 flex flex-col items-center justify-center border border-dashed rounded-xl p-3 ${
                            isDarkMode ? 'border-slate-800' : 'border-slate-100'
                          }`}>
                            <span className="text-[10px] text-slate-400 italic text-center leading-tight">Mata Kuliah Kosong</span>
                          </div>
                        ) : (
                          dayItems.map(item => (
                            <div 
                              key={item.id}
                              className={`p-2 rounded-xl border text-left flex flex-col justify-between relative group hover:scale-[1.01] transition-all overflow-hidden ${getScheduleColor(item.type)}`}
                            >
                              <div className="flex items-start justify-between gap-1">
                                <p className="text-xs font-bold leading-snug tracking-tight truncate flex-1 block">
                                  {item.title}
                                </p>
                                
                                {/* Edit and Delete mini buttons on hover */}
                                <div className="flex items-center gap-1 opacity-100 xl:opacity-0 xl:group-hover:opacity-100 transition-opacity">
                                  <button
                                    onClick={() => startEditSchedule(item)}
                                    className="p-0.5 rounded text-slate-400 hover:text-ocean transition-all"
                                    title="Modifikasi Kelas"
                                  >
                                    <Edit2 size={10} />
                                  </button>
                                  <button
                                    onClick={() => removeSchedule(item.id)}
                                    className="p-0.5 rounded text-slate-400 hover:text-rose-500 transition-all"
                                    title="Hapus Kelas"
                                  >
                                    <Trash2 size={10} />
                                  </button>
                                </div>
                              </div>

                              <div className="flex items-center justify-between gap-1 mt-1 text-[9px] opacity-80 min-w-0 font-medium">
                                <span className="truncate flex items-center gap-0.5">
                                  <Clock size={8} /> {item.startTime}-{item.endTime}
                                </span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: TRADITIONAL COMPACT TIMELINE LIST */}
          {scheduleViewMode === 'list' && (
            <div className="space-y-4">
              {schedule.length === 0 ? (
                <div className={`p-10 rounded-3xl border-2 border-dashed text-center flex flex-col items-center justify-center ${
                  isDarkMode ? 'border-slate-800' : 'border-slate-100 bg-white'
                }`}>
                  <CalendarIcon size={32} className="text-slate-400 mb-2" />
                  <p className="text-sm font-bold text-slate-500">Anda belum membuat mata kuliah apapun.</p>
                  <p className="text-xs text-slate-400 mt-1">Gunakan tombol 'Tambah Jadwal' atau ganti ke mode kalender.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {schedule.map((item) => (
                    <motion.div
                      layout
                      key={item.id}
                      className={`p-4 md:p-5 rounded-2xl border shadow-sm hover:shadow-md transition-all group relative overflow-hidden ${getScheduleColor(item.type)}`}
                    >
                      {/* Left border categories highlight indicator */}
                      <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${getSchedulePillTypeColor(item.type)}`} />

                      <div className="flex items-start justify-between">
                        <div className="flex gap-3 md:gap-4 ml-1">
                          <div className={`shrink-0 w-12 h-12 flex flex-col items-center justify-center rounded-xl border transition-colors ${
                            isDarkMode ? 'bg-black/25 border-white/5' : 'bg-white/60 border-white/40'
                          }`}>
                            <span className={`text-[10px] text-center font-bold tracking-wider uppercase block ${isDarkMode ? 'text-slate-405' : 'text-slate-500'}`}>
                              {item.day}
                            </span>
                          </div>
                          <div>
                            <h3 className="font-bold text-sm md:text-base tracking-tight">{item.title}</h3>
                            <div className="flex flex-wrap items-center gap-2 md:gap-3 mt-1.5 text-[11px] opacity-80 font-medium">
                              <div className="flex items-center gap-1">
                                <Clock size={11} />
                                <span>{item.startTime} - {item.endTime}</span>
                              </div>
                              <span className="w-1 h-1 bg-current opacity-30 rounded-full" />
                              <span className="capitalize">{
                                item.type === 'class' ? 'Kuliah Tatap Muka' 
                                : item.type === 'study' ? 'Belajar Mandiri' 
                                : 'Istirahat'
                              }</span>
                            </div>
                          </div>
                        </div>

                        {/* Edit & Delete CTA controls */}
                        <div className="flex items-center gap-1.5 shrink-0 opacity-100 xl:opacity-0 xl:group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => startEditSchedule(item)}
                            className="p-2 transition-all rounded-lg border bg-white/20 hover:bg-white/40 text-current hover:text-ocean"
                            title="Edit Sesi"
                          >
                            <Edit2 size={14} strokeWidth={2} />
                          </button>
                          <button 
                            onClick={() => removeSchedule(item.id)}
                            className="p-2 transition-all rounded-lg border bg-white/20 hover:bg-white/40 text-current hover:text-rose-500"
                            title="Hapus Sesi"
                          >
                            <Trash2 size={14} strokeWidth={2} />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SCHEDULE CHANGE LOGS & ARCHIVED LOGICAL PREV STATES */}
          {scheduleViewMode === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className={`text-sm font-bold flex items-center gap-1.5 ${isDarkMode?'text-slate-300':'text-slate-800'}`}>
                  <History size={16} className="text-ocean" /> Riwayat Penyuntingan Jadwal Kuliah
                </h3>
                {scheduleHistory.length > 0 && clearScheduleHistory && (
                  <button
                    onClick={() => {
                      if (confirm("Apakah Anda yakin mau membersihkan semua catatan histori jadwal?")) {
                        clearScheduleHistory();
                      }
                    }}
                    className="text-[10px] font-bold text-rose-500 hover:underline"
                  >
                    Bersihkan Riwayat
                  </button>
                )}
              </div>

              {scheduleHistory.length === 0 ? (
                <div className={`p-10 rounded-2xl border-2 border-dashed text-center flex flex-col items-center justify-center ${
                  isDarkMode ? 'border-slate-800' : 'border-slate-100 bg-white'
                }`}>
                  <History size={26} className="text-slate-400 mb-2" />
                  <p className="text-xs font-bold text-slate-500">Belum ada riwayat terekam.</p>
                  <p className="text-[10px] text-slate-400 mt-1">Setiap kali Anda menambah, memodifikasi, atau menghapus jadwal, rekaman lama akan disimpan di sini.</p>
                </div>
              ) : (
                <div className="space-y-3.5 max-h-[480px] overflow-y-auto no-scrollbar pr-1">
                  {scheduleHistory.map((hist) => {
                    const parsedDate = new Date(hist.timestamp);
                    const localTimeString = parsedDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                    const localDateString = parsedDate.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });

                    return (
                      <div
                        key={hist.id}
                        className={`p-3.5 rounded-2xl border flex items-center justify-between gap-4 text-left transition-all ${
                          isDarkMode ? 'bg-slate-900/50 border-slate-800' : 'bg-white border-slate-100 shadow-sm'
                        }`}
                      >
                        <div className="flex-1 min-w-0">
                          <p className={`text-xs font-semibold leading-relaxed ${isDarkMode ? 'text-slate-205' : 'text-slate-700'}`}>
                            {hist.description}
                          </p>
                          <div className="flex items-center gap-1.5 mt-1 text-[10px] text-slate-400 font-bold">
                            <span className="text-ocean">{hist.actionType.toUpperCase()}</span>
                            <span>•</span>
                            <span>{localDateString} pukul {localTimeString}</span>
                          </div>
                        </div>

                        {/* Reversion action triggers */}
                        {restoreScheduleHistory && hist.actionType !== 'restore' && (
                          <button
                            onClick={() => restoreScheduleHistory(hist)}
                            className={`flex items-center gap-1 py-1.5 px-3 rounded-xl border text-[10px] font-bold shrink-0 transition-transform active:scale-95 ${
                              isDarkMode 
                              ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white' 
                              : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-ocean'
                            }`}
                            title="Pulihkan data lama untuk tindakan ini"
                          >
                            <RotateCcw size={10} />
                            Batal Sesi
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

        </div>
      )}

      {/* Tasks Management Section */}
      {(!showOnly || showOnly === 'tugas') && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 md:gap-3">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-colors ${isDarkMode ? 'bg-slate-800 text-ocean' : 'bg-sky-light text-ocean'}`}>
                <CheckCircle2 size={20} className="text-ocean" />
              </div>
              <div>
                <h2 className={`text-xl md:text-2xl font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Daftar Tugas</h2>
                <p className="text-xs text-slate-400 mt-0.5">Pantau tugas dan deadline kuliah Anda.</p>
              </div>
            </div>
            <button 
              onClick={() => setShowTaskForm(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-ocean text-white rounded-xl text-xs sm:text-sm font-bold shadow-lg shadow-ocean/20 hover:scale-105 transition-all"
            >
              <Plus size={16} />
              Tambah Tugas
            </button>
          </div>

          {/* Add Task Form Modal */}
          <AnimatePresence>
            {showTaskForm && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98, y: 15 }}
                className={`p-5 rounded-3xl border shadow-inner ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-sky-light/50 border-sky-100'}`}
              >
                <form onSubmit={handleAddTask} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Deskripsi Tugas</label>
                    <input
                      type="text"
                      placeholder="Apa yang harus dikumpulkan? Contoh: Makalah Riset Bab 2..."
                      className={`w-full p-3.5 rounded-2xl border focus:outline-none focus:ring-2 focus:ring-ocean transition-all text-sm font-medium ${
                        isDarkMode ? 'bg-slate-700 border-slate-600 text-white placeholder:text-slate-500' : 'bg-white border-slate-150 text-slate-800'
                      }`}
                      value={newTask.title}
                      onChange={e => setNewTask({...newTask, title: e.target.value})}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Tanggal Batas Pengumpulan</label>
                      <input
                        type="date"
                        className={`w-full p-3.5 rounded-2xl border focus:outline-none focus:ring-2 focus:ring-ocean font-semibold text-sm ${
                          isDarkMode ? 'bg-slate-700 border-slate-600 text-white' : 'bg-white border-slate-155 text-slate-800'
                        }`}
                        value={newTask.deadline}
                        onChange={e => setNewTask({...newTask, deadline: e.target.value})}
                        required
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Prioritas</label>
                      <select
                        className={`w-full p-3.5 rounded-2xl border focus:outline-none focus:ring-2 focus:ring-ocean font-semibold text-sm cursor-pointer appearance-none ${
                          isDarkMode ? 'bg-slate-700 border-slate-600 text-white' : 'bg-white border-slate-155 text-slate-800'
                        }`}
                        value={newTask.priority}
                        onChange={e => setNewTask({...newTask, priority: e.target.value as 'low'|'medium'|'high'})}
                      >
                        <option value="low">🟡 Rendah</option>
                        <option value="medium">🟠 Sedang</option>
                        <option value="high">🔴 Penting / Darurat</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button 
                      type="submit"
                      className="flex-1 bg-ocean text-white py-3 rounded-2xl font-bold shadow-lg shadow-ocean/20 hover:opacity-95 transition-all text-sm"
                    >
                      Simpan Tugas
                    </button>
                    <button 
                      type="button"
                      onClick={() => setShowTaskForm(false)}
                      className={`px-6 py-3 rounded-2xl font-bold transition-all text-sm ${
                        isDarkMode ? 'bg-slate-700 text-slate-400 hover:bg-slate-600' : 'bg-white text-slate-400 hover:bg-slate-100'
                      }`}
                    >
                      Batal
                    </button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Tasks Stack cards list */}
          <div className="space-y-3">
            {tasks.length === 0 ? (
              <div className={`p-10 rounded-3xl border-2 border-dashed text-center flex flex-col items-center justify-center ${
                isDarkMode ? 'border-slate-800' : 'border-slate-100 bg-white'
              }`}>
                <CheckCircle2 size={32} className="text-slate-400 mb-2" />
                <p className="text-sm font-bold text-slate-500">Semua tugas beres!</p>
                <p className="text-xs text-slate-400 mt-1">Santai dulu atau tambah tugas kuliah baru lewat tombol di atas.</p>
              </div>
            ) : (
              <AnimatePresence mode="popLayout">
                {tasks.map((task) => (
                  <motion.div
                    key={task.id}
                    layout
                    initial={{ opacity: 0, x: -25 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className={`p-4 rounded-2xl border-2 flex items-center justify-between gap-3 md:gap-4 transition-all duration-300 group ${
                      task.isCompleted 
                        ? (isDarkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-100/40 border-slate-200/50 backdrop-blur-md opacity-75')
                        : (isDarkMode ? 'bg-slate-850 border-slate-800' : 'bg-white/60 border-white/80 backdrop-blur-md shadow-lg shadow-indigo-100/10 hover:shadow-xl hover:scale-[1.01]')
                    }`}
                  >
                    <div className="flex items-center gap-3 md:gap-4 flex-1 min-w-0">
                      <button 
                        onClick={() => toggleTask(task.id)}
                        className={`shrink-0 transition-colors ${task.isCompleted ? 'text-emerald-500' : isDarkMode ? 'text-slate-600 hover:text-ocean' : 'text-slate-250 hover:text-ocean'}`}
                      >
                        {task.isCompleted ? <CheckCircle2 size={22} fill="currentColor" stroke="white" /> : <Circle size={22} />}
                      </button>
                      <div className="flex-1 min-w-0 text-left">
                        <h3 className={`font-semibold md:text-[15px] transition-all truncate ${
                          task.isCompleted 
                            ? (isDarkMode ? 'text-slate-600 line-through' : 'text-slate-400 line-through')
                            : (isDarkMode ? 'text-slate-200' : 'text-slate-800')
                        }`}>
                          {task.title}
                        </h3>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <span className="text-[10px] text-slate-400 font-bold whitespace-nowrap">Deadline: {task.deadline}</span>
                          <span className={`text-[9px] md:text-[10px] uppercase font-black px-2 py-0.5 rounded-full border ${getPriorityColor(task.priority)} ${isDarkMode && task.priority !== 'medium' ? 'brightness-125' : ''}`}>
                            {task.priority === 'high' ? 'PENTING' : task.priority === 'medium' ? 'SEDANG' : 'RENDAH'}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button 
                      onClick={() => removeTask(task.id)}
                      className="text-slate-300 hover:text-rose-500 p-2 scale-90 md:opacity-0 group-hover:opacity-100 transition-all shrink-0"
                    >
                      <Trash2 size={16} />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
