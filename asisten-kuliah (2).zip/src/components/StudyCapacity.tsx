/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area, PieChart, Pie, Cell, Legend 
} from 'recharts';
import { 
  BookOpen, Plus, Trash2, Calendar, Award, Flame, Hourglass, 
  Sparkles, Sliders, CheckCircle, Brain, RefreshCw, AlertCircle 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Task } from '../types';

interface StudySession {
  id: string;
  subject: string;
  duration: number; // in minutes
  date: string; // YYYY-MM-DD
  focusLevel: number; // 1-5 scale
  note?: string;
}

interface StudyCapacityProps {
  isDarkMode: boolean;
  tasks: Task[];
}

const DEFAULT_SUBJECTS = [
  'Matematika',
  'Pemrograman',
  'Fisika',
  'Biologi',
  'Sastra',
  'Metode Penelitian',
  'Lainnya'
];

export default function StudyCapacity({ isDarkMode, tasks }: StudyCapacityProps) {
  // Try to load initial sessions or seed descriptive data if empty
  const [sessions, setSessions] = useState<StudySession[]>(() => {
    const saved = localStorage.getItem('asisten_study_sessions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse saved sessions", e);
      }
    }
    
    // Seed gorgeous initial data for last 7 days to showcase the graphics instantly
    const today = new Date();
    const seeded: StudySession[] = [];
    const subjects = ['Pemrograman', 'Matematika', 'Fisika', 'Sastra', 'Pemrograman', 'Biologi'];
    
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      
      // Seed 1 or 2 sessions for most days
      if (i !== 3) { // Skip one day for realistic empty slot
        seeded.push({
          id: `seed-${i}-1`,
          subject: subjects[i % subjects.length],
          duration: 45 + (i * 15) % 90, // 45 to 135 mins
          date: dateStr,
          focusLevel: Math.floor(Math.random() * 2) + 4, // 4 or 5
          note: 'Sesi belajar mandiri di perpustakaan.'
        });
      }
      if (i === 1 || i === 5) {
        seeded.push({
          id: `seed-${i}-2`,
          subject: subjects[(i + 2) % subjects.length],
          duration: 30 + (i * 10),
          date: dateStr,
          focusLevel: 3,
          note: 'Mempelajari bab yang sulit.'
        });
      }
    }
    return seeded;
  });

  const [dailyTarget, setDailyTarget] = useState<number>(() => {
    const saved = localStorage.getItem('asisten_study_target');
    return saved ? Number(saved) : 120; // 2 hours default
  });

  // State for session inputs
  const [subject, setSubject] = useState(DEFAULT_SUBJECTS[0]);
  const [customSubject, setCustomSubject] = useState('');
  const [duration, setDuration] = useState(60);
  const [focusLevel, setFocusLevel] = useState(4);
  const [note, setNote] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [showLogForm, setShowLogForm] = useState(false);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('asisten_study_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('asisten_study_target', String(dailyTarget));
  }, [dailyTarget]);

  // Aggregate stats
  const totalDuration = sessions.reduce((sum, s) => sum + s.duration, 0);
  const avgFocus = sessions.length > 0 
    ? (sessions.reduce((sum, s) => sum + s.focusLevel, 0) / sessions.length).toFixed(1) 
    : '0';

  // Get today's logged study duration
  const todayStr = new Date().toISOString().split('T')[0];
  const todayDuration = sessions
    .filter(s => s.date === todayStr)
    .reduce((sum, s) => sum + s.duration, 0);

  // Completed tasks count
  const completedTasksCount = tasks.filter(t => t.isCompleted).length;

  // Add new session
  const handleAddSession = (e: React.FormEvent) => {
    e.preventDefault();
    const finalSubject = subject === 'Lainnya' && customSubject.trim() !== '' 
      ? customSubject.trim() 
      : subject;

    const newSession: StudySession = {
      id: `session-${Date.now()}`,
      subject: finalSubject,
      duration: Number(duration),
      date,
      focusLevel,
      note: note.trim() || undefined
    };

    setSessions(prev => [newSession, ...prev]);
    setNote('');
    setCustomSubject('');
    setDuration(60);
    setFocusLevel(4);
    setShowLogForm(false);
  };

  // Remove session
  const handleRemoveSession = (id: string) => {
    setSessions(prev => prev.filter(s => s.id !== id));
  };

  // Prepares daily study time chart data (last 7 days)
  const getWeeklyChartData = () => {
    const days = [];
    const today = new Date();
    
    // Day names Indonesian
    const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
    
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      
      const daySessions = sessions.filter(s => s.date === dateStr);
      const durationSum = daySessions.reduce((sum, s) => sum + s.duration, 0);
      
      days.push({
        name: dayNames[d.getDay()],
        date: dateStr,
        'Durasi (Menit)': durationSum,
        'Target': dailyTarget,
      });
    }
    return days;
  };

  // Prep data for subject pie-chart
  const getSubjectChartData = () => {
    const subMap: Record<string, number> = {};
    sessions.forEach(s => {
      subMap[s.subject] = (subMap[s.subject] || 0) + s.duration;
    });

    return Object.entries(subMap).map(([name, value]) => ({
      name,
      value
    }));
  };

  // Prep focus level analysis chart data
  const getFocusChartData = () => {
    const levelCounts = [0, 0, 0, 0, 0]; // for levels 1, 2, 3, 4, 5
    sessions.forEach(s => {
      if (s.focusLevel >= 1 && s.focusLevel <= 5) {
        levelCounts[s.focusLevel - 1] += 1;
      }
    });

    return levelCounts.map((count, index) => ({
      fokus: `Level ${index + 1}`,
      'Jumlah Sesi': count
    }));
  };

  const subjectData = getSubjectChartData();
  const weeklyData = getWeeklyChartData();
  const focusData = getFocusChartData();

  // Color palette for Pie Chart
  const COLORS = ['#0077b6', '#00b4d8', '#2dd4bf', '#fbbf24', '#f87171', '#818cf8', '#ec4899'];

  // AI Insights generator based on metrics
  const getStudyInsights = () => {
    const hours = (totalDuration / 60).toFixed(1);
    const avgFocused = Number(avgFocus);

    if (sessions.length === 0) {
      return {
        title: "Belum Ada Aktivitas Belajar",
        icon: Brain,
        color: "text-amber-500 bg-amber-500/10",
        message: "Asisten siap mengukur kapasitas belajarmu! Silakan catat sesi belajar pertamamu menggunakan tombol di atas, atau putar timer Fokus untuk memulai."
      };
    }

    if (avgFocused >= 4 && todayDuration >= dailyTarget) {
      return {
        title: "Kapasitas & Fokus Sempurna!",
        icon: Award,
        color: "text-emerald-500 bg-emerald-500/10",
        message: `Luar biasa, hari ini kapasitas belajarmu sangat optimal mencapai ${todayDuration} menit dengan tingkat fokus rata-rata yang sangat tinggi (${avgFocus}/5). Kognitif Anda berada pada kondisi puncak!`
      };
    }

    if (avgFocused < 3) {
      return {
        title: "Konsentrasi Perlu Ditingkatkan",
        icon: AlertCircle,
        color: "text-rose-500 bg-rose-500/10",
        message: `Durasi belajar Anda total ${hours} jam, tetapi tingkat fokus Anda rata-rata di bawah 3. Cobalah batasi aplikasi media sosial selama belajar atau gunakan metode Pomodoro (25 menit belajar, 5 menit rehat).`
      };
    }

    if (totalDuration > 0 && totalDuration < 120) {
      return {
        title: "Mulai Membangun Momentum",
        icon: Flame,
        color: "text-cyan-500 bg-cyan-500/10",
        message: "Kapasitas belajarmu mulai meningkat secara bertahap. Pertahankan konsistensi ini setiap harinya untuk membangun kebiasaan belajar (study habit) yang sehat!"
      };
    }

    return {
      title: "Pola Belajar Sangat Hebat",
      icon: Sparkles,
      color: "text-indigo-500 bg-indigo-500/10",
      message: `Rata-rata kapasitas belajar Anda berjalan stabil dengan fokus rata-rata ${avgFocus}/5. Jaga hidrasi tubuh, istirahat teratur, dan rancang jadwal belajar harianmu agar tidak burnout.`
    };
  };

  const insight = getStudyInsights();

  // Progress percentage of today's target
  const todayProgressPercent = Math.min(Math.round((todayDuration / dailyTarget) * 100), 100);

  return (
    <div className="space-y-6 pb-20">
      {/* Header section with Target controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className={`text-xl md:text-2xl font-bold flex items-center gap-2 ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>
            <Brain className="text-ocean" /> Kapasitas Belajar
          </h2>
          <p className="text-slate-400 text-xs md:text-sm mt-1">Ukur performa harian, fokus kognitif, dan distribusi waktu kuliahmu.</p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowLogForm(!showLogForm)}
            className="flex items-center gap-2 bg-ocean hover:bg-ocean/90 text-white px-4 py-2 rounded-2xl shadow-md text-sm font-semibold transition-all scale-100 active:scale-95"
          >
            <Plus size={16} /> Catat Sesi Manual
          </button>
        </div>
      </div>

      {/* Log Form Dialog (Animate Presence) */}
      <AnimatePresence>
        {showLogForm && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`p-6 rounded-3xl border shadow-2xl relative overflow-hidden ${isDarkMode ? 'bg-slate-900/90 border-slate-800/80 backdrop-blur-md' : 'bg-white/90 border-white/80 backdrop-blur-md shadow-amber-100/10'}`}
          >
            <form onSubmit={handleAddSession} className="space-y-4">
              <h3 className={`font-bold flex items-center gap-2 ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>
                <BookOpen size={18} className="text-ocean" /> Input Sesi Belajar Baru
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Subject Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">MATA KULIAH / TOPIK</label>
                  <select
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm focus:ring-2 focus:ring-ocean outline-none ${
                      isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    {DEFAULT_SUBJECTS.map(sub => (
                      <option key={sub} value={sub}>{sub}</option>
                    ))}
                  </select>
                </div>

                {/* Custom Subject (if 'Lainnya' selected) */}
                {subject === 'Lainnya' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">TULIS TOPIK KUSTOM</label>
                    <input
                      type="text"
                      required
                      placeholder="Masukkan nama mata kuliah..."
                      value={customSubject}
                      onChange={(e) => setCustomSubject(e.target.value)}
                      className={`w-full px-4 py-2.5 rounded-xl border text-sm focus:ring-2 focus:ring-ocean outline-none ${
                        isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    />
                  </div>
                )}

                {/* Date Picker */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">TANGGAL BELAJAR</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm focus:ring-2 focus:ring-ocean outline-none ${
                      isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  />
                </div>

                {/* Duration Slider */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">DURASI BELAJAR (MENIT): {duration} Menit</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min="10"
                      max="240"
                      step="5"
                      value={duration}
                      onChange={(e) => setDuration(Number(e.target.value))}
                      className="flex-1 accent-ocean"
                    />
                    <input 
                      type="number"
                      min="10"
                      max="240"
                      value={duration}
                      onChange={(e) => setDuration(Math.max(10, Math.min(240, Number(e.target.value))))}
                      className={`w-16 text-center px-2 py-1 rounded-lg border text-xs font-bold ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'}`}
                    />
                  </div>
                </div>

                {/* Focus Level Scale (1 to 5 stars) */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-2">TINGKAT FOKUS / KONSESTRASI (1-5)</label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((level) => (
                      <button
                        type="button"
                        key={level}
                        onClick={() => setFocusLevel(level)}
                        className={`w-10 h-10 rounded-xl font-bold border transition-all flex items-center justify-center ${
                          focusLevel === level
                            ? 'bg-ocean border-ocean text-white shadow-md'
                            : isDarkMode 
                              ? 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white' 
                              : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Note input */}
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">CATATAN SINGKAT (OPSIONAL)</label>
                <input
                  type="text"
                  placeholder="Contoh: Selesai mereview bab 3, latihan soal 1-5"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className={`w-full px-4 py-2 rounded-xl border text-sm focus:ring-2 focus:ring-ocean outline-none ${
                    isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-slate-50 border-slate-200'
                  }`}
                />
              </div>

              {/* Button controls */}
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLogForm(false)}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold border ${
                    isDarkMode ? 'border-slate-700 text-slate-300 hover:bg-slate-800' : 'border-slate-200 text-slate-500 hover:bg-slate-100'
                  }`}
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-ocean text-white rounded-xl text-sm font-semibold shadow-md hover:bg-ocean/90 hover:scale-[1.02] transition-all"
                >
                  Simpan Sesi
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main KPI metrics bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Today's Goal Gauge card */}
        <div className={`p-5 rounded-3xl border flex items-center gap-4 transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div className="relative w-16 h-16 flex items-center justify-center">
            {/* Circular progress bar */}
            <svg className="w-full h-full -rotate-90">
              <circle
                cx="32"
                cy="32"
                r="26"
                className={`fill-none stroke-current stroke-3 ${isDarkMode ? 'text-slate-800' : 'text-slate-100'}`}
              />
              <circle
                cx="32"
                cy="32"
                r="26"
                className="fill-none stroke-ocean stroke-3 transition-all duration-500"
                strokeDasharray={`${2 * Math.PI * 26}`}
                strokeDashoffset={`${2 * Math.PI * 26 * (1 - todayProgressPercent / 100)}`}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className={`text-base font-bold ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{todayProgressPercent}%</span>
            </div>
          </div>
          <div>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Hari Ini</p>
            <h3 className={`text-xl font-black ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{todayDuration} m</h3>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-[10px] text-slate-400">Target: {dailyTarget}m</span>
              <button 
                onClick={() => {
                  const newTarget = prompt("Masukkan target belajar baru (menit):", String(dailyTarget));
                  if (newTarget) {
                    const parsed = parseInt(newTarget);
                    if (!isNaN(parsed) && parsed > 0) {
                      setDailyTarget(parsed);
                    }
                  }
                }}
                className="text-[10px] text-ocean hover:underline font-bold"
              >
                Ubah
              </button>
            </div>
          </div>
        </div>

        {/* Total hours */}
        <div className={`p-5 rounded-3xl border flex items-center gap-4 transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div className="p-3 bg-ocean/10 text-ocean rounded-2xl">
            <Hourglass size={24} />
          </div>
          <div>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Kumulatif Waktu</p>
            <h3 className={`text-xl font-black ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{(totalDuration / 60).toFixed(1)} Jam</h3>
            <p className="text-[10px] text-slate-400 mt-0.5">{sessions.length} Sesi Terdaftar</p>
          </div>
        </div>

        {/* Average Focus */}
        <div className={`p-5 rounded-3xl border flex items-center gap-4 transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div className="p-3 bg-amber-500/10 text-amber-500 rounded-2xl animate-pulse">
            <Flame size={24} />
          </div>
          <div>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Rerata Fokus</p>
            <h3 className={`text-xl font-black ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{avgFocus} / 5.0</h3>
            <p className="text-[10px] text-amber-500 font-bold mt-0.5">Konsentrasi Maksimal</p>
          </div>
        </div>

        {/* Task correlation */}
        <div className={`p-5 rounded-3xl border flex items-center gap-4 transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div className="p-3 bg-emerald-500/10 text-emerald-500 rounded-2xl">
            <CheckCircle size={24} />
          </div>
          <div>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Tugas Diselesaikan</p>
            <h3 className={`text-xl font-black ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{completedTasksCount} Tugas</h3>
            <p className="text-[10px] text-slate-500 mt-0.5">Efisiensi Belajar Tinggi</p>
          </div>
        </div>
      </div>

      {/* AI recommendation alert */}
      <div className={`p-5 rounded-3xl border flex items-start gap-4 transition-colors ${isDarkMode ? 'bg-slate-900/40 border-slate-800/60' : 'bg-slate-50 border-slate-100'}`}>
        <div className={`p-3 rounded-2xl shrink-0 ${insight.color}`}>
          <insight.icon size={22} className="" />
        </div>
        <div>
          <h4 className={`font-bold text-sm flex items-center gap-2 ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>
            {insight.title} <Sparkles size={14} className="text-amber-400 animate-bounce" />
          </h4>
          <p className="text-slate-400 text-xs mt-1 leading-relaxed">{insight.message}</p>
        </div>
      </div>

      {/* Graphics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Graphic 1: Weekly Study Duration (Area Chart) - Occupies 7 columns */}
        <div className={`lg:col-span-7 p-6 rounded-3xl border transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className={`font-bold text-base ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Tren Kapasitas Belajar (7 Hari Terakhir)</h3>
              <p className="text-xs text-slate-400">Durasi belajar harian dibandingkan target waktu belajar.</p>
            </div>
          </div>
          
          <div className="h-64 md:h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weeklyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorDuration" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0077b6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#0077b6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? '#334155' : '#f1f5f9'} />
                <XAxis 
                  dataKey="name" 
                  stroke={isDarkMode ? '#64748b' : '#94a3b8'} 
                  fontSize={11}
                  tickLine={false} 
                />
                <YAxis 
                  stroke={isDarkMode ? '#64748b' : '#94a3b8'} 
                  fontSize={11}
                  tickLine={false} 
                  axisLine={false}
                />
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '16px',
                    backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                    border: isDarkMode ? '1px solid #334155' : '1px solid #e2e8f0',
                    color: isDarkMode ? '#f8fafc' : '#0f172a'
                  }} 
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', marginTop: '10px' }} />
                <Area 
                  type="monotone" 
                  dataKey="Durasi (Menit)" 
                  stroke="#0077b6" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorDuration)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="Target" 
                  stroke="#94a3b8" 
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  fillOpacity={0} 
                  fill="none" 
                  strokeOpacity={0.6}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Graphic 2: Subjects Focus Allocation (Pie Chart) - Occupies 5 columns */}
        <div className={`lg:col-span-5 p-6 rounded-3xl border transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div>
            <h3 className={`font-bold text-base ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Distribusi Alokasi Berdasarkan Mapel</h3>
            <p className="text-xs text-slate-400 mb-6">Proporsi waktu belajar Anda yang dicurahkan pada topik kuliah.</p>
          </div>

          <div className="h-64 w-full flex items-center justify-center relative">
            {subjectData.length === 0 ? (
              <div className="text-center p-4">
                <p className="text-slate-400 text-xs">Belum ada data mata kuliah. Sesi belajar yang dicatatkan akan muncul di sini.</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={subjectData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {subjectData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value} Menit`, 'Total Waktu']}
                    contentStyle={{ 
                      borderRadius: '16px',
                      backgroundColor: isDarkMode ? '#1e293b' : '#ffffff',
                      border: isDarkMode ? '1px solid #334155' : '1px solid #e2e8f0',
                      color: isDarkMode ? '#f8fafc' : '#0f172a'
                    }} 
                  />
                  <Legend iconType="circle" layout="vertical" align="right" verticalAlign="middle" wrapperStyle={{ fontSize: '10px' }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Graphic 3: Concentration metrics (Focus score chart) and session list footer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Focus Level Distribution */}
        <div className={`p-6 rounded-3xl border transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div className="mb-4">
            <h3 className={`font-bold text-base ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Penyebaran Tingkat Fokus</h3>
            <p className="text-xs text-slate-400">Jumlah sesi belajar berdasarkan level konsentrasi kognitif (1 s/d 5).</p>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={focusData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? '#334155' : '#f1f5f9'} />
                <XAxis 
                  dataKey="fokus" 
                  stroke={isDarkMode ? '#64748b' : '#94a3b8'} 
                  fontSize={10}
                  tickLine={false} 
                />
                <YAxis 
                  stroke={isDarkMode ? '#64748b' : '#94a3b8'} 
                  fontSize={10}
                  tickLine={false} 
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '16px',
                    borderColor: isDarkMode ? '#334155' : '#e2e8f0',
                    backgroundColor: isDarkMode ? '#1e293b' : '#fff'
                  }} 
                />
                <Bar dataKey="Jumlah Sesi" fill="#00b4d8" radius={[8, 8, 0, 0]} maxBarSize={35} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* History of Study Sessions */}
        <div className={`p-6 rounded-3xl border h-[340px] flex flex-col transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className={`font-bold text-base ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Catatan Riwayat Belajar</h3>
              <p className="text-xs text-slate-400">Riwayat sesi belajar yang terdaftar aplikasi.</p>
            </div>
            
            {sessions.length > 0 && (
              <button 
                onClick={() => {
                  if (confirm("Apakah Anda yakin ingin menghapus semua riwayat belajar?")) {
                    setSessions([]);
                  }
                }}
                className="text-xs text-rose-500 font-bold hover:underline flex items-center gap-1"
              >
                Reset Semua
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar space-y-3 pr-1">
            {sessions.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-4">
                <BookOpen size={30} className="text-slate-400 mb-2" />
                <p className="text-xs text-slate-400">Belum ada riwayat tercatat. Silakan tambah sesi belajar baru.</p>
              </div>
            ) : (
              <AnimatePresence initial={false}>
                {sessions.map((session) => (
                  <motion.div
                    key={session.id}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className={`p-3.5 rounded-2xl border flex items-center justify-between gap-4 relative overflow-hidden group ${
                      isDarkMode ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-100 hover:bg-slate-100/50'
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-ocean uppercase truncate max-w-[120px] sm:max-w-[180px]">
                          {session.subject}
                        </span>
                        <span className="text-[10px] text-slate-400 flex items-center gap-1 bg-slate-200/50 dark:bg-slate-700/50 px-2 py-0.5 rounded-full">
                          <Calendar size={10} /> {session.date}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2.5 text-xs text-slate-500 dark:text-slate-400">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          ⏱️ {session.duration} Menit
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1 text-amber-500 font-bold">
                          ★ Level {session.focusLevel} Fokus
                        </span>
                      </div>

                      {session.note && (
                        <p className={`text-[11px] mt-1 italic truncate ${isDarkMode ? 'text-slate-400/80': 'text-slate-500/80'}`}>
                          "{session.note}"
                        </p>
                      )}
                    </div>

                    <button
                      onClick={() => handleRemoveSession(session.id)}
                      className={`p-2 transition-all rounded-xl border opacity-100 lg:opacity-0 lg:group-hover:opacity-100 scale-90 hover:scale-100 ${
                        isDarkMode 
                        ? 'bg-slate-800 hover:bg-rose-950/40 border-slate-700 text-slate-500 hover:text-rose-400' 
                        : 'bg-white hover:bg-rose-50 border-slate-200 text-slate-400 hover:text-rose-600'
                      }`}
                    >
                      <Trash2 size={15} />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
