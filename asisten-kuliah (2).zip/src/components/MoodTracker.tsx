/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trash2, History, Calendar, Clock, MessageSquare, Heart, Sparkles, TrendingUp } from 'lucide-react';
import { MoodEntry } from '../types';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

interface MoodProps {
  isDarkMode: boolean;
  aiName: string;
  moodHistory: MoodEntry[];
  onAddEntry: (entry: Omit<MoodEntry, 'id'>) => void;
  onRemoveEntry: (id: string) => void;
}

export default function MoodTracker({ isDarkMode, aiName, moodHistory, onAddEntry, onRemoveEntry }: MoodProps) {
  const moods = [
    { emoji: '🤩', label: 'Luar Biasa', id: 'great', color: 'bg-amber-400', border: 'border-amber-200', value: 5 },
    { emoji: '😊', label: 'Senang', id: 'good', color: 'bg-emerald-400', border: 'border-emerald-200', value: 4 },
    { emoji: '😐', label: 'Biasa Saja', id: 'neutral', color: 'bg-sky-400', border: 'border-sky-200', value: 3 },
    { emoji: '🥱', label: 'Lelah', id: 'tired', color: 'bg-indigo-400', border: 'border-indigo-200', value: 2 },
    { emoji: '😰', label: 'Stres', id: 'stressed', color: 'bg-rose-400', border: 'border-rose-200', value: 1 },
  ] as const;

  const [selectedMoodId, setSelectedMoodId] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const [showGratitude, setShowGratitude] = useState(false);

  const getDayName = (date: Date) => {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    return days[date.getDay()];
  };

  const handleSubmit = () => {
    if (!selectedMoodId) return;
    
    const moodObj = moods.find(m => m.id === selectedMoodId);
    if (!moodObj) return;

    const now = new Date();
    
    onAddEntry({
      date: now.toISOString(),
      day: getDayName(now),
      time: now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      mood: selectedMoodId as any,
      label: moodObj.label,
      emoji: moodObj.emoji,
      note: note.trim() || undefined
    });

    setNote('');
    setSelectedMoodId(null);
    setShowGratitude(true);
    
    setTimeout(() => {
      setShowGratitude(false);
    }, 3000);
  };

  // Prepare chart data
  const chartData = [...moodHistory]
    .reverse()
    .slice(-7) // Last 7 entries
    .map(entry => {
      const moodObj = moods.find(m => m.id === entry.mood);
      return {
        date: new Date(entry.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'short' }),
        value: moodObj?.value || 3,
        label: entry.label,
        emoji: entry.emoji
      };
    });

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className={`p-3 rounded-2xl border shadow-xl ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
          <p className="text-[10px] text-slate-400 mb-1 font-bold">{payload[0].payload.date}</p>
          <div className="flex items-center gap-2">
            <span className="text-xl">{payload[0].payload.emoji}</span>
            <span className={`font-bold text-sm ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{payload[0].payload.label}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 max-w-2xl mx-auto w-full pb-10">
      {/* Tracker Section */}
      <section className={`p-6 md:p-8 rounded-3xl shadow-sm border transition-all ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-xl shadow-indigo-100/10'}`}>
        <AnimatePresence mode="wait">
          {showGratitude ? (
            <motion.div 
              key="gratitude"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="py-10 text-center"
            >
              <div className="text-5xl md:text-6xl mb-6">💖</div>
              <h2 className={`text-2xl md:text-3xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Tersimpan!</h2>
              <p className={`text-sm md:text-lg leading-relaxed ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Terima kasih sudah berbagi perasaanmu. {aiName} siap menemanimu belajar!
              </p>
            </motion.div>
          ) : (
            <motion.div 
              key="form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-6"
            >
              <div>
                <h2 className={`text-xl md:text-2xl font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Halo! Apa Kabar Hari Ini?</h2>
                <p className="text-sm md:text-base text-ocean/80 font-medium">{aiName} ingin tahu kabarmu hari ini...</p>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                {moods.map((mood) => (
                  <button
                    key={mood.id}
                    onClick={() => setSelectedMoodId(mood.id)}
                    className={`flex flex-col items-center gap-2 p-3 rounded-2xl transition-all border-2 ${
                      selectedMoodId === mood.id 
                        ? `${mood.border} ${mood.color} text-white shadow-lg scale-105` 
                        : `${isDarkMode ? 'bg-slate-800/50 border-slate-800 text-slate-500' : 'border-slate-50 bg-slate-50 text-slate-400'} hover:scale-105`
                    }`}
                  >
                    <span className="text-3xl md:text-4xl">{mood.emoji}</span>
                    <span className="text-[10px] md:text-xs font-bold truncate w-full text-center">{mood.label}</span>
                  </button>
                ))}
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <MessageSquare size={16} className="text-ocean" />
                  <label className={`font-bold text-sm ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>Catatan Kecil</label>
                </div>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Tulis apa yang kamu rasakan (misal: senang karena tugas selesai!)"
                  className={`w-full p-4 rounded-2xl border-2 transition-all text-sm focus:border-ocean focus:outline-none ${isDarkMode ? 'bg-slate-800 border-slate-800 text-white focus:bg-slate-900/50' : 'bg-slate-50 border-slate-50 text-slate-800 focus:bg-white'}`}
                  rows={2}
                />
              </div>

              <button
                onClick={handleSubmit}
                disabled={!selectedMoodId}
                className={`w-full py-4 rounded-2xl font-bold text-base shadow-lg transition-all flex items-center justify-center gap-2 ${
                  selectedMoodId 
                    ? 'bg-ocean text-white shadow-ocean/20 hover:scale-[1.01] active:scale-[0.99]' 
                    : 'bg-slate-200 text-slate-400 pointer-events-none'
                }`}
              >
                <Heart size={18} fill={selectedMoodId ? "currentColor" : "none"} />
                Simpan Kondisiku
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Stats/Trends Section */}
      {moodHistory.length >= 2 && (
        <section className={`p-6 rounded-3xl border ${isDarkMode ? 'bg-slate-900/50 border-slate-800/80 backdrop-blur-md' : 'bg-white/60 border-white/60 backdrop-blur-md shadow-lg shadow-indigo-100/10'}`}>
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp size={20} className="text-ocean" />
            <h3 className={`font-bold text-lg ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Tren Mood Kamu</h3>
          </div>
          
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? "#1e293b" : "#f1f5f9"} />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#94a3b8' }} 
                />
                <YAxis 
                  hide={true} 
                  domain={[1, 5]} 
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#0ea5e9" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 flex justify-between px-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Dulu</span>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Sekarang</span>
          </div>
        </section>
      )}

      {/* History Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="text-ocean" size={20} />
            <h3 className={`font-bold text-lg ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Riwayat Kondisimu</h3>
          </div>
          <span className="text-[10px] md:text-xs font-bold bg-ocean/10 text-ocean px-3 py-1 rounded-full">
            {moodHistory.length} Catatan
          </span>
        </div>

        <div className="space-y-4">
          {moodHistory.length > 0 ? (
            moodHistory.map((entry, index) => (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                key={entry.id}
                className={`group p-4 md:p-5 rounded-3xl border transition-all hover:shadow-md ${isDarkMode ? 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-900/60' : 'bg-white/60 border-white/60 backdrop-blur-md hover:border-ocean/20 shadow-xs'}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-4">
                    <div className={`shrink-0 w-12 h-12 md:w-14 md:h-14 rounded-2xl flex items-center justify-center text-3xl shadow-sm ${isDarkMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
                      {entry.emoji}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className={`font-bold ${isDarkMode ? 'text-slate-200' : 'text-slate-800'}`}>{entry.label}</h4>
                        <span className="w-1 h-1 bg-slate-300 rounded-full" />
                        <div className="flex items-center gap-3 text-[10px] md:text-xs text-slate-400 font-medium">
                          <div className="flex items-center gap-1">
                            <Calendar size={12} />
                            <span>{entry.day}, {new Date(entry.date).toLocaleDateString('id-ID')}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock size={12} />
                            <span>{entry.time}</span>
                          </div>
                        </div>
                      </div>
                      
                      {entry.note ? (
                        <p className={`mt-2 text-xs md:text-sm leading-relaxed p-3 rounded-xl border-l-4 ${isDarkMode ? 'bg-slate-800/50 border-ocean/30 text-slate-300' : 'bg-sky-50/50 border-sky-200 text-slate-600 italic'}`}>
                          "{entry.note}"
                        </p>
                      ) : (
                        <p className="mt-1 text-[10px] text-slate-400 italic">Tidak ada catatan.</p>
                      )}
                    </div>
                  </div>
                  
                  <button
                    onClick={() => onRemoveEntry(entry.id)}
                    className="p-2 rounded-xl text-slate-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </motion.div>
            ))
          ) : (
            <div className={`p-10 rounded-3xl border border-dashed text-center space-y-3 ${isDarkMode ? 'bg-slate-900/20 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
              <div className="text-4xl grayscale opacity-30">📅</div>
              <p className="text-slate-400 text-sm italic">Belum ada riwayat mood. Yuk, catat kabarmu sekarang!</p>
            </div>
          )}
        </div>
      </section>

      {/* Wellness Tip */}
      <div className={`p-6 rounded-2xl border transition-colors ${isDarkMode ? 'bg-ocean/10 border-ocean/20 shadow-[0_0_20px_rgba(14,165,233,0.05)]' : 'bg-sky-light border-sky-200'}`}>
        <h4 className="font-bold text-ocean mb-2 flex items-center gap-2 text-sm">
          <Sparkles size={16} /> Tips Kesehatan Belajar:
        </h4>
        <p className={`text-xs md:text-sm leading-relaxed ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
          "Mencatat perasaan membantu Anda mengenali pola stres saat kuliah. Jika merasa jenuh, cobalah teknik pernapasan 4-7-8 selama 5 menit!"
        </p>
      </div>
    </div>
  );
}


